"""
indices/vegetation_indices.py
================================
Compute NDVI, SAVI, and MSAVI2 from super-resolution-enhanced Landsat imagery.

Mathematical formulations
--------------------------
NDVI  (Equation 5):   NDVI  = (NIR - RED) / (NIR + RED)
SAVI  (Equation 6):   SAVI  = (1 + L) × (NIR - RED) / (NIR + RED + L)     [L = 0.5]
MSAVI2(Equation 7):   MSAVI2 = (2·NIR + 1 - √[(2·NIR + 1)² - 8(NIR - RED)]) / 2

All indices are clipped to [-1, 1].

Usage
-----
    python indices/vegetation_indices.py \
        --sr_images results/srgan \
        --output    results/indices
"""

import os
import argparse
import logging
from glob import glob

import numpy as np
import rasterio
from rasterio.transform import from_bounds
import pandas as pd

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LANDSAT, VI, RES_INDICES, RES_SRGAN

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

# Band indices in the stacked 6-band Landsat GeoTIFF (0-indexed)
# Order from preprocessing: blue(0), green(1), red(2), nir(3), swir1(4), swir2(5)
BAND_RED  = 2
BAND_NIR  = 3
EPSILON   = 1e-10     # avoid division by zero


# ---------------------------------------------------------------------------
# Index calculations
# ---------------------------------------------------------------------------

def compute_ndvi(nir: np.ndarray, red: np.ndarray) -> np.ndarray:
    """
    Normalized Difference Vegetation Index (NDVI).

    Parameters
    ----------
    nir, red : np.ndarray, same shape, float32

    Returns
    -------
    ndvi : np.ndarray, float32, clipped to [-1, 1]
    """
    denom = nir + red
    ndvi  = np.where(np.abs(denom) > EPSILON, (nir - red) / denom, 0.0)
    return np.clip(ndvi, -1.0, 1.0).astype(np.float32)


def compute_savi(nir: np.ndarray, red: np.ndarray, L: float = 0.5) -> np.ndarray:
    """
    Soil-Adjusted Vegetation Index (SAVI).

    Parameters
    ----------
    nir, red : np.ndarray, same shape, float32
    L        : soil brightness correction factor (default 0.5)

    Returns
    -------
    savi : np.ndarray, float32, clipped to [-1, 1]
    """
    denom = nir + red + L
    savi  = np.where(np.abs(denom) > EPSILON,
                     (1.0 + L) * (nir - red) / denom,
                     0.0)
    return np.clip(savi, -1.0, 1.0).astype(np.float32)


def compute_msavi2(nir: np.ndarray, red: np.ndarray) -> np.ndarray:
    """
    Modified Soil-Adjusted Vegetation Index 2 (MSAVI2).

    MSAVI2 = (2·NIR + 1 - √[(2·NIR + 1)² - 8·(NIR - RED)]) / 2

    Parameters
    ----------
    nir, red : np.ndarray, same shape, float32

    Returns
    -------
    msavi2 : np.ndarray, float32, clipped to [-1, 1]
    """
    two_nir_plus1 = 2.0 * nir + 1.0
    discriminant  = two_nir_plus1 ** 2 - 8.0 * (nir - red)
    # Clamp discriminant to ≥ 0 (can be slightly negative due to float rounding)
    discriminant  = np.maximum(discriminant, 0.0)
    msavi2 = (two_nir_plus1 - np.sqrt(discriminant)) / 2.0
    return np.clip(msavi2, -1.0, 1.0).astype(np.float32)


def compute_all_indices(
    nir: np.ndarray,
    red: np.ndarray,
    L: float = 0.5,
) -> dict[str, np.ndarray]:
    """
    Compute NDVI, SAVI, and MSAVI2 in one call.

    Returns
    -------
    dict mapping index name → np.ndarray
    """
    return {
        "ndvi"  : compute_ndvi(nir, red),
        "savi"  : compute_savi(nir, red, L=L),
        "msavi2": compute_msavi2(nir, red),
    }


# ---------------------------------------------------------------------------
# GeoTIFF I/O
# ---------------------------------------------------------------------------

def indices_from_geotiff(
    tif_path: str,
    output_dir: str,
    scene_id: str | None = None,
) -> dict[str, str]:
    """
    Read a stacked Landsat GeoTIFF and compute all three vegetation indices.
    Saves one GeoTIFF per index and returns their paths.

    Parameters
    ----------
    tif_path   : path to stacked 6-band GeoTIFF (band order: B,G,R,NIR,SWIR1,SWIR2)
    output_dir : output directory
    scene_id   : optional scene identifier used in file names

    Returns
    -------
    dict mapping index name → output path
    """
    os.makedirs(output_dir, exist_ok=True)
    if scene_id is None:
        scene_id = os.path.splitext(os.path.basename(tif_path))[0]

    with rasterio.open(tif_path) as src:
        data  = src.read().astype(np.float32)   # (C, H, W)
        meta  = src.meta.copy()

    nir = data[BAND_NIR, :, :]
    red = data[BAND_RED, :, :]
    indices = compute_all_indices(nir, red, L=VI["savi_L"])

    out_paths = {}
    meta.update({"count": 1, "dtype": np.float32, "nodata": np.nan})

    for index_name, arr in indices.items():
        out_path = os.path.join(output_dir, f"{scene_id}_{index_name}.tif")
        with rasterio.open(out_path, "w", **meta) as dst:
            dst.write(arr[np.newaxis, :, :])
        out_paths[index_name] = out_path
        log.info("Saved %s → %s", index_name.upper(), out_path)

    return out_paths


def regional_statistics(
    index_tif: str,
) -> dict[str, float]:
    """
    Compute mean, std, min, max for a single-band vegetation index GeoTIFF.
    """
    with rasterio.open(index_tif) as src:
        arr = src.read(1).astype(np.float32)
    valid = arr[~np.isnan(arr)]
    if len(valid) == 0:
        return {"mean": np.nan, "std": np.nan, "min": np.nan, "max": np.nan}
    return {
        "mean": float(np.mean(valid)),
        "std" : float(np.std(valid)),
        "min" : float(np.min(valid)),
        "max" : float(np.max(valid)),
    }


# ---------------------------------------------------------------------------
# Time-series builder
# ---------------------------------------------------------------------------

def build_vi_timeseries(
    sr_dir: str,
    output_dir: str,
) -> pd.DataFrame:
    """
    Process all SR GeoTIFFs in *sr_dir*, compute vegetation indices for each,
    and assemble a monthly time-series CSV.

    Expects file names to include a date string in the format YYYY-MM, e.g.:
        LC08_L2SP_168039_20200115_stacked_utm38n_srgan_sr.tif

    Returns
    -------
    pd.DataFrame with columns [date, scene_id, ndvi_mean, ndvi_std, …]
    """
    os.makedirs(output_dir, exist_ok=True)
    tif_files = sorted(glob(os.path.join(sr_dir, "*.tif")))

    if not tif_files:
        log.warning("No GeoTIFF files found in %s.", sr_dir)
        return pd.DataFrame()

    records = []
    for tif_path in tif_files:
        scene_id = os.path.splitext(os.path.basename(tif_path))[0]
        log.info("Computing vegetation indices for %s …", scene_id)

        try:
            out_paths = indices_from_geotiff(tif_path, output_dir, scene_id=scene_id)
        except Exception as exc:
            log.error("Failed on %s: %s", scene_id, exc)
            continue

        row = {"scene_id": scene_id}
        for index_name, tif_out in out_paths.items():
            stats = regional_statistics(tif_out)
            for stat_name, val in stats.items():
                row[f"{index_name}_{stat_name}"] = val
        records.append(row)

    df      = pd.DataFrame(records)
    csv_out = os.path.join(output_dir, "vegetation_indices_timeseries.csv")
    df.to_csv(csv_out, index=False)
    log.info("Vegetation index time series saved → %s", csv_out)
    return df


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compute NDVI, SAVI, MSAVI2 from SR-enhanced Landsat GeoTIFFs."
    )
    parser.add_argument("--sr_images", default=RES_SRGAN,
                        help="Directory containing SR GeoTIFF scenes.")
    parser.add_argument("--output",    default=RES_INDICES,
                        help="Output directory for vegetation index GeoTIFFs and CSV.")
    parser.add_argument("--single",    default=None,
                        help="Process a single GeoTIFF instead of a directory.")
    args = parser.parse_args()

    if args.single:
        indices_from_geotiff(args.single, args.output)
    else:
        build_vi_timeseries(args.sr_images, args.output)


if __name__ == "__main__":
    main()
