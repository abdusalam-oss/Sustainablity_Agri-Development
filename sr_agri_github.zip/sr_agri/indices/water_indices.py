"""
indices/water_indices.py
=========================
Compute water-related spectral indices from Landsat SR imagery.

Indices implemented
-------------------
NDWI  — Normalized Difference Water Index (McFeeters 1996)
         NDWI  = (GREEN - NIR) / (GREEN + NIR)

MNDWI — Modified NDWI (Xu 2006)
         MNDWI = (GREEN - SWIR1) / (GREEN + SWIR1)

AWEInsh — Automated Water Extraction Index, no-shadow (Feyisa et al. 2014)
           AWEInsh = 4(GREEN - SWIR1) - (0.25·NIR + 2.75·SWIR2)

AWEIsh  — AWE shadow (Feyisa et al. 2014)
           AWEIsh  = BLUE + 2.5·GREEN - 1.5(NIR + SWIR1) - 0.25·SWIR2

Water extraction mask is derived by thresholding MNDWI ≥ 0.

Usage
-----
    python indices/water_indices.py \
        --sr_images results/srgan \
        --output    results/indices
"""

import os
import argparse
import logging
from glob import glob

import numpy as np
import rasterio
import pandas as pd

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import RES_INDICES, RES_SRGAN

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

# Band indices (0-indexed) for the 6-band stacked Landsat GeoTIFF
BAND_BLUE  = 0
BAND_GREEN = 1
BAND_RED   = 2
BAND_NIR   = 3
BAND_SWIR1 = 4
BAND_SWIR2 = 5

EPSILON = 1e-10
MNDWI_WATER_THRESHOLD = 0.0    # pixels ≥ 0 are classified as water


# ---------------------------------------------------------------------------
# Index functions
# ---------------------------------------------------------------------------

def compute_ndwi(green: np.ndarray, nir: np.ndarray) -> np.ndarray:
    """NDWI = (GREEN - NIR) / (GREEN + NIR)."""
    denom = green + nir
    ndwi  = np.where(np.abs(denom) > EPSILON, (green - nir) / denom, 0.0)
    return np.clip(ndwi, -1.0, 1.0).astype(np.float32)


def compute_mndwi(green: np.ndarray, swir1: np.ndarray) -> np.ndarray:
    """MNDWI = (GREEN - SWIR1) / (GREEN + SWIR1)."""
    denom  = green + swir1
    mndwi  = np.where(np.abs(denom) > EPSILON, (green - swir1) / denom, 0.0)
    return np.clip(mndwi, -1.0, 1.0).astype(np.float32)


def compute_awei_nsh(
    green: np.ndarray,
    nir:   np.ndarray,
    swir1: np.ndarray,
    swir2: np.ndarray,
) -> np.ndarray:
    """AWEInsh = 4(GREEN - SWIR1) - (0.25·NIR + 2.75·SWIR2)."""
    return (4.0 * (green - swir1) - (0.25 * nir + 2.75 * swir2)).astype(np.float32)


def compute_awei_sh(
    blue:  np.ndarray,
    green: np.ndarray,
    nir:   np.ndarray,
    swir1: np.ndarray,
    swir2: np.ndarray,
) -> np.ndarray:
    """AWEIsh = BLUE + 2.5·GREEN - 1.5(NIR + SWIR1) - 0.25·SWIR2."""
    return (blue + 2.5 * green - 1.5 * (nir + swir1) - 0.25 * swir2).astype(np.float32)


def water_mask_from_mndwi(
    mndwi: np.ndarray,
    threshold: float = MNDWI_WATER_THRESHOLD,
) -> np.ndarray:
    """Return a boolean mask: True = water pixel."""
    return (mndwi >= threshold).astype(bool)


def compute_all_water_indices(data: np.ndarray) -> dict[str, np.ndarray]:
    """
    Compute all water indices from a 6-band stacked array.

    Parameters
    ----------
    data : (C, H, W) float32 array in [0, 1]

    Returns
    -------
    dict mapping index name → (H, W) array
    """
    blue  = data[BAND_BLUE,  :, :]
    green = data[BAND_GREEN, :, :]
    nir   = data[BAND_NIR,   :, :]
    swir1 = data[BAND_SWIR1, :, :]
    swir2 = data[BAND_SWIR2, :, :]

    mndwi = compute_mndwi(green, swir1)
    return {
        "ndwi"     : compute_ndwi(green, nir),
        "mndwi"    : mndwi,
        "awei_nsh" : compute_awei_nsh(green, nir, swir1, swir2),
        "awei_sh"  : compute_awei_sh(blue, green, nir, swir1, swir2),
        "water_mask": water_mask_from_mndwi(mndwi).astype(np.float32),
    }


# ---------------------------------------------------------------------------
# GeoTIFF I/O
# ---------------------------------------------------------------------------

def water_indices_from_geotiff(
    tif_path: str,
    output_dir: str,
    scene_id: str | None = None,
) -> dict[str, str]:
    """
    Read a stacked Landsat GeoTIFF and compute all water indices.
    """
    os.makedirs(output_dir, exist_ok=True)
    if scene_id is None:
        scene_id = os.path.splitext(os.path.basename(tif_path))[0]

    with rasterio.open(tif_path) as src:
        data = src.read().astype(np.float32)   # (C, H, W)
        meta = src.meta.copy()

    indices  = compute_all_water_indices(data)
    out_paths = {}
    meta.update({"count": 1, "dtype": np.float32, "nodata": np.nan})

    for name, arr in indices.items():
        out_path = os.path.join(output_dir, f"{scene_id}_{name}.tif")
        with rasterio.open(out_path, "w", **meta) as dst:
            dst.write(arr[np.newaxis, :, :])
        out_paths[name] = out_path

    log.info("Water indices saved for scene %s.", scene_id)
    return out_paths


def water_area_timeseries(
    sr_dir: str,
    output_dir: str,
    pixel_area_ha: float = 0.09,   # 30m × 30m = 0.09 ha
) -> pd.DataFrame:
    """
    Compute water-covered area (ha) per scene from MNDWI masks.

    Parameters
    ----------
    sr_dir        : directory containing stacked SR GeoTIFFs
    output_dir    : output directory
    pixel_area_ha : area of one pixel in hectares (0.09 for 30 m Landsat)

    Returns
    -------
    pd.DataFrame with columns [scene_id, water_pixels, water_area_ha,
                                ndwi_mean, mndwi_mean]
    """
    os.makedirs(output_dir, exist_ok=True)
    tif_files = sorted(glob(os.path.join(sr_dir, "*.tif")))
    records   = []

    for tif_path in tif_files:
        scene_id = os.path.splitext(os.path.basename(tif_path))[0]
        out_paths = water_indices_from_geotiff(tif_path, output_dir, scene_id=scene_id)

        with rasterio.open(out_paths["water_mask"]) as src:
            mask = src.read(1).astype(bool)
        with rasterio.open(out_paths["ndwi"]) as src:
            ndwi_arr = src.read(1)
        with rasterio.open(out_paths["mndwi"]) as src:
            mndwi_arr = src.read(1)

        n_water = int(mask.sum())
        records.append({
            "scene_id"      : scene_id,
            "water_pixels"  : n_water,
            "water_area_ha" : n_water * pixel_area_ha,
            "ndwi_mean"     : float(np.nanmean(ndwi_arr)),
            "mndwi_mean"    : float(np.nanmean(mndwi_arr)),
        })
        log.info("Scene %s — water area: %.1f ha.", scene_id, n_water * pixel_area_ha)

    df      = pd.DataFrame(records)
    csv_out = os.path.join(output_dir, "water_area_timeseries.csv")
    df.to_csv(csv_out, index=False)
    log.info("Water area time series saved → %s", csv_out)
    return df


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compute NDWI, MNDWI, AWEI water indices from SR Landsat scenes."
    )
    parser.add_argument("--sr_images", default=RES_SRGAN,
                        help="Directory containing SR GeoTIFF scenes.")
    parser.add_argument("--output",    default=RES_INDICES)
    parser.add_argument("--single",    default=None)
    args = parser.parse_args()

    if args.single:
        water_indices_from_geotiff(args.single, args.output)
    else:
        water_area_timeseries(args.sr_images, args.output)


if __name__ == "__main__":
    main()
