"""
preprocessing/pme_qc.py
========================
PME Met Station rainfall quality-control and gap-filling pipeline.

Steps
-----
1. Load the raw PME Buraidah monthly rainfall CSV from KAPSARC.
2. Parse and standardise date columns.
3. Remove outliers beyond ±3 standard deviations of the monthly mean.
4. Gap-fill runs of ≤ 3 consecutive missing months by linear interpolation.
5. Flag months that were gap-filled or outlier-removed.
6. Export cleaned CSV and a diagnostic summary.

Usage
-----
    python preprocessing/pme_qc.py \
        --input  data/raw/pme_station \
        --output data/processed/pme

Data source
-----------
General Authority for Statistics, KAPSARC Data Portal (2024).
https://datasource.kapsarc.org/explore/dataset/
average-atmospheric-pressure-in-hpmb-observed-by-pme-met-stations-2009xls0/information/
"""

import os
import argparse
import logging
from glob import glob
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.interpolate import interp1d

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import PME, PROC_PME

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_raw_csv(csv_path: str) -> pd.DataFrame:
    """
    Load the raw PME Met Station CSV.

    Expected columns (flexible): year, month, rainfall_mm  — or variations
    such as 'Year', 'Month', 'Rainfall (mm)', etc.
    """
    df = pd.read_csv(csv_path, encoding="utf-8-sig")   # BOM-safe

    # Normalise column names
    df.columns = [c.strip().lower().replace(" ", "_").replace("(", "").replace(")", "")
                  for c in df.columns]

    # Map common column name variants
    rename_map = {}
    for col in df.columns:
        if "year" in col:
            rename_map[col] = "year"
        elif "month" in col and "rainfall" not in col:
            rename_map[col] = "month"
        elif "rain" in col or "precip" in col:
            rename_map[col] = "rainfall_mm"
    df = df.rename(columns=rename_map)

    required = {"year", "month", "rainfall_mm"}
    missing  = required - set(df.columns)
    if missing:
        raise ValueError(
            f"CSV {csv_path} is missing required columns: {missing}. "
            f"Found: {list(df.columns)}"
        )

    df["year"]        = df["year"].astype(int)
    df["month"]       = df["month"].astype(int)
    df["rainfall_mm"] = pd.to_numeric(df["rainfall_mm"], errors="coerce")

    df["date"] = pd.to_datetime(
        df["year"].astype(str) + "-" + df["month"].astype(str).str.zfill(2)
    )
    df = df.sort_values("date").reset_index(drop=True)
    return df[["date", "year", "month", "rainfall_mm"]]


def _ensure_complete_monthly_index(df: pd.DataFrame,
                                   start_year: int, end_year: int) -> pd.DataFrame:
    """
    Reindex *df* to a complete monthly DatetimeIndex from start to end.
    Missing months will have NaN rainfall.
    """
    full_idx = pd.date_range(
        start=f"{start_year}-01-01",
        end  =f"{end_year}-12-01",
        freq ="MS",
    )
    df = df.set_index("date").reindex(full_idx)
    df.index.name  = "date"
    df["year"]     = df.index.year
    df["month"]    = df.index.month
    return df.reset_index()


def _remove_outliers(df: pd.DataFrame, col: str, std_threshold: float) -> pd.DataFrame:
    """
    Remove outliers: values more than *std_threshold* × σ from the
    monthly (calendar month) mean are set to NaN and flagged.
    """
    df["flag_outlier"] = False
    for m in range(1, 13):
        mask = df["month"] == m
        vals = df.loc[mask, col]
        mean = vals.mean()
        std  = vals.std()
        if std == 0 or np.isnan(std):
            continue
        outlier = mask & (np.abs(df[col] - mean) > std_threshold * std)
        df.loc[outlier, col]           = np.nan
        df.loc[outlier, "flag_outlier"] = True
    n_out = df["flag_outlier"].sum()
    log.info("Outlier removal: %d months flagged.", n_out)
    return df


def _gap_fill(df: pd.DataFrame, col: str, max_gap: int) -> pd.DataFrame:
    """
    Linear interpolation for gaps of ≤ *max_gap* consecutive NaN months.
    Larger gaps remain NaN.
    """
    df["flag_gap_filled"] = False
    values = df[col].copy()

    # Find NaN runs
    nan_mask = values.isna()
    if not nan_mask.any():
        return df

    # Label consecutive runs of NaN
    run_id    = (nan_mask != nan_mask.shift()).cumsum()
    run_sizes = nan_mask.groupby(run_id).transform("sum")

    fill_mask = nan_mask & (run_sizes <= max_gap)

    # Interpolate on the subset that can be filled
    tmp   = values.copy()
    tmp   = tmp.interpolate(method="linear", limit=max_gap, limit_direction="both")
    values[fill_mask] = tmp[fill_mask]

    df[col]                = values
    df["flag_gap_filled"]  = fill_mask
    n_filled = fill_mask.sum()
    log.info("Gap filling: %d months interpolated (max gap = %d).", n_filled, max_gap)
    return df


def _monthly_climatology(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Return a DataFrame with calendar-month mean and std."""
    return df.groupby("month")[col].agg(["mean", "std", "count"]).reset_index()


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

def process_pme(input_dir: str, output_dir: str) -> None:
    """
    Run the full PME QC pipeline on all CSV files in *input_dir*.
    """
    os.makedirs(output_dir, exist_ok=True)
    csv_files = sorted(glob(os.path.join(input_dir, "*.csv")))

    if not csv_files:
        log.error("No CSV files found in %s.", input_dir)
        return

    all_frames = []
    for csv_path in csv_files:
        log.info("Loading %s …", os.path.basename(csv_path))
        try:
            df = _load_raw_csv(csv_path)
        except Exception as exc:
            log.error("Could not load %s: %s", csv_path, exc)
            continue

        log.info("  Loaded %d records spanning %s – %s.",
                 len(df), df["date"].min(), df["date"].max())

        df = _ensure_complete_monthly_index(df, PME["start_year"], PME["end_year"])
        df = _remove_outliers(df, "rainfall_mm", PME["outlier_std"])
        df = _gap_fill(df, "rainfall_mm", PME["gap_fill_max_months"])
        df["source_file"] = os.path.basename(csv_path)
        all_frames.append(df)

    if not all_frames:
        log.error("No valid PME data processed.")
        return

    combined = pd.concat(all_frames, ignore_index=True).sort_values("date")

    # Summary statistics per calendar month (climatology)
    climatology = _monthly_climatology(combined, "rainfall_mm")

    # Export
    clean_csv = os.path.join(output_dir, "pme_buraidah_rainfall_clean.csv")
    clim_csv  = os.path.join(output_dir, "pme_buraidah_climatology.csv")
    combined.to_csv(clean_csv, index=False)
    climatology.to_csv(clim_csv, index=False)

    log.info("Cleaned PME rainfall data saved → %s", clean_csv)
    log.info("Monthly climatology saved → %s", clim_csv)

    # Diagnostic summary
    n_total   = len(combined)
    n_missing = combined["rainfall_mm"].isna().sum()
    n_out     = combined.get("flag_outlier", pd.Series(False, index=combined.index)).sum()
    n_filled  = combined.get("flag_gap_filled", pd.Series(False, index=combined.index)).sum()
    log.info(
        "QC summary: %d months total | %d outliers removed | "
        "%d months gap-filled | %d remaining NaN.",
        n_total, n_out, n_filled, n_missing,
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Quality-control and gap-fill PME Met Station rainfall records."
    )
    parser.add_argument("--input",  default=os.path.join(os.path.dirname(os.path.dirname(
                                        os.path.abspath(__file__))), "data", "raw", "pme_station"),
                        help="Directory containing raw PME CSV files.")
    parser.add_argument("--output", default=PROC_PME,
                        help="Output directory for cleaned CSV files.")
    args = parser.parse_args()
    process_pme(args.input, args.output)


if __name__ == "__main__":
    main()
