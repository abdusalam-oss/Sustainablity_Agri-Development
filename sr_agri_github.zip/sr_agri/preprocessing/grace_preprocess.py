"""
preprocessing/grace_preprocess.py
===================================
GRACE Terrestrial Water Storage (TWS) anomaly preprocessing pipeline.

Steps
-----
1. Load GRACE monthly .nc files (JPL mascon product, RL06.1).
2. Apply DDK5 Gaussian smoothing filter to suppress north–south striping.
3. Convert units: cm equivalent water height → mm.
4. Replace fill values with NaN.
5. Clip to the Al-Qassim bounding box.
6. Export one GeoTIFF per month and a combined monthly time-series CSV.

Usage
-----
    python preprocessing/grace_preprocess.py \
        --input  data/raw/grace \
        --output data/processed/grace

Data source
-----------
GRACE / GRACE-FO: https://www.eoportal.org/satellite-missions/grace
JPL mascon product: https://podaac.jpl.nasa.gov/dataset/TELLUS_GRAC-GRFO_MASCON_CRI_GRID_RL06.1_V3
"""

import os
import argparse
import logging
from glob import glob
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import from_bounds
from rasterio.crs import CRS
from scipy.ndimage import gaussian_filter
import netCDF4 as nc4

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import GRACE, STUDY_AREA, PROC_GRACE

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DDK5 spatial filter
# ---------------------------------------------------------------------------
# The DDK5 filter is an anisotropic decorrelation filter (Kusche 2007).
# For post-processed mascon solutions it simplifies to a mild Gaussian
# smoothing (σ ≈ 1 grid cell) applied along the along-track direction.
# Here we apply a symmetric Gaussian with σ = 1.5 cells as an approximation
# suitable for the mascon product already pre-filtered at JPL.
DDK5_SIGMA = 1.5   # grid cells


def _apply_ddk5(data: np.ndarray) -> np.ndarray:
    """Apply approximate DDK5 de-striping via anisotropic Gaussian smoothing."""
    # Smooth more in the N-S direction (along satellite track) than E-W
    sigma = (DDK5_SIGMA * 2.0, DDK5_SIGMA * 0.5)
    filtered = gaussian_filter(data, sigma=sigma)
    return filtered.astype(np.float32)


# ---------------------------------------------------------------------------
# Spatial clipping helpers
# ---------------------------------------------------------------------------

def _lon_lat_indices(lons: np.ndarray, lats: np.ndarray) -> tuple:
    """Return row/column index slices for the Al-Qassim bounding box."""
    min_lon, min_lat, max_lon, max_lat = STUDY_AREA["bbox_wgs84"]
    col_mask = (lons >= min_lon) & (lons <= max_lon)
    row_mask = (lats >= min_lat) & (lats <= max_lat)
    col_idx  = np.where(col_mask)[0]
    row_idx  = np.where(row_mask)[0]
    return row_idx, col_idx


# ---------------------------------------------------------------------------
# Main processing
# ---------------------------------------------------------------------------

def process_grace_nc(nc_path: str, output_dir: str) -> pd.DataFrame:
    """
    Process a GRACE NetCDF file.

    Parameters
    ----------
    nc_path    : Path to the GRACE .nc file.
    output_dir : Directory to write per-month GeoTIFFs.

    Returns
    -------
    DataFrame with columns [date, mean_tws_mm, std_tws_mm, min_tws_mm, max_tws_mm]
    for the clipped Al-Qassim region.
    """
    os.makedirs(output_dir, exist_ok=True)
    records = []

    with nc4.Dataset(nc_path, "r") as ds:
        lons  = ds.variables["lon"][:]
        lats  = ds.variables["lat"][:]
        times = ds.variables["time"]
        tws   = ds.variables[GRACE["variable"]]

        # Decode time units → datetime
        try:
            import cftime
            dates = nc4.num2date(times[:], units=times.units, calendar=getattr(times, "calendar", "standard"))
            dates = [pd.Timestamp(d.year, d.month, d.day) for d in dates]
        except Exception:
            # Fallback: assume days since 2002-01-01
            dates = [pd.Timestamp("2002-01-01") + pd.Timedelta(days=float(t)) for t in times[:]]

        fill_val = getattr(tws, "_FillValue", GRACE["fill_value"])
        row_idx, col_idx = _lon_lat_indices(np.array(lons), np.array(lats))

        for t_idx, date in enumerate(dates):
            date_str = date.strftime("%Y-%m")

            # Filter by requested date range
            if date_str < GRACE["start_date"] or date_str > GRACE["end_date"]:
                continue

            data = np.array(tws[t_idx, :, :], dtype=np.float32)

            # Replace fill value
            data[data == fill_val] = np.nan

            # DDK5 filter (applied to full global grid before clipping)
            valid_mask  = ~np.isnan(data)
            data_filled = np.where(valid_mask, data, 0.0)
            data_filt   = _apply_ddk5(data_filled)
            data_filt[~valid_mask] = np.nan

            # Convert cm → mm
            data_mm = data_filt * 10.0

            # Clip to study area
            clipped = data_mm[np.ix_(row_idx, col_idx)]
            sub_lons = np.array(lons)[col_idx]
            sub_lats = np.array(lats)[row_idx]

            # Build GeoTIFF transform (origin = upper-left corner)
            res_lon = float(sub_lons[1] - sub_lons[0]) if len(sub_lons) > 1 else 0.5
            res_lat = float(sub_lats[1] - sub_lats[0]) if len(sub_lats) > 1 else 0.5
            transform = from_bounds(
                west  = float(sub_lons.min()) - res_lon / 2,
                south = float(sub_lats.min()) - abs(res_lat) / 2,
                east  = float(sub_lons.max()) + res_lon / 2,
                north = float(sub_lats.max()) + abs(res_lat) / 2,
                width = clipped.shape[1],
                height= clipped.shape[0],
            )

            out_tif = os.path.join(output_dir, f"grace_tws_{date_str}.tif")
            with rasterio.open(
                out_tif, "w",
                driver   = "GTiff",
                dtype    = np.float32,
                count    = 1,
                height   = clipped.shape[0],
                width    = clipped.shape[1],
                transform= transform,
                crs      = CRS.from_epsg(4326),
                nodata   = np.nan,
            ) as dst:
                dst.write(clipped[np.newaxis, :, :])

            # Regional statistics
            valid_vals = clipped[~np.isnan(clipped)]
            records.append({
                "date"         : date_str,
                "mean_tws_mm"  : float(np.nanmean(valid_vals))  if len(valid_vals) else np.nan,
                "std_tws_mm"   : float(np.nanstd(valid_vals))   if len(valid_vals) else np.nan,
                "min_tws_mm"   : float(np.nanmin(valid_vals))   if len(valid_vals) else np.nan,
                "max_tws_mm"   : float(np.nanmax(valid_vals))   if len(valid_vals) else np.nan,
                "n_valid_cells": int(len(valid_vals)),
            })
            log.info("Processed GRACE %s — mean TWS anomaly = %.2f mm.", date_str,
                     records[-1]["mean_tws_mm"] if not np.isnan(records[-1]["mean_tws_mm"]) else 0.0)

    df = pd.DataFrame(records).sort_values("date").reset_index(drop=True)
    return df


def process_grace_directory(input_dir: str, output_dir: str) -> None:
    """
    Process all GRACE .nc files in *input_dir*.
    Writes per-month GeoTIFFs and a combined CSV time series.
    """
    nc_files = sorted(glob(os.path.join(input_dir, "*.nc")))
    if not nc_files:
        log.error("No .nc files found in %s.", input_dir)
        return

    all_records = []
    for nc_path in nc_files:
        log.info("Processing %s …", os.path.basename(nc_path))
        df = process_grace_nc(nc_path, output_dir)
        all_records.append(df)

    combined = pd.concat(all_records, ignore_index=True).sort_values("date")
    csv_out  = os.path.join(output_dir, "grace_tws_alqassim_timeseries.csv")
    combined.to_csv(csv_out, index=False)
    log.info("Saved combined GRACE time series (%d months) → %s", len(combined), csv_out)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Preprocess GRACE TWS anomaly data for the Al-Qassim region."
    )
    parser.add_argument("--input",  default=os.path.join(os.path.dirname(os.path.dirname(
                                        os.path.abspath(__file__))), "data", "raw", "grace"),
                        help="Directory containing GRACE .nc files.")
    parser.add_argument("--output", default=PROC_GRACE,
                        help="Output directory for GeoTIFFs and CSV.")
    args = parser.parse_args()

    process_grace_directory(args.input, args.output)


if __name__ == "__main__":
    main()
