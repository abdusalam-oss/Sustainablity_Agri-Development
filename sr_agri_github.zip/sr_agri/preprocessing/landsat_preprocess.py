"""
preprocessing/landsat_preprocess.py
=====================================
Landsat Collection 2 Level-2 Surface Reflectance preprocessing pipeline.

Steps
-----
1. Discover all Landsat scenes in the raw directory.
2. Apply QA_PIXEL cloud / cloud-shadow / snow masking (keep < 10 % cloud cover).
3. Apply scale factor and offset to convert DN to surface reflectance.
4. Reproject to WGS 84 / UTM Zone 38N (EPSG:32638) and clip to the
   Al-Qassim bounding box.
5. Extract overlapping LR (32 × 32) / HR (128 × 128) patch pairs for
   super-resolution model training (HR = native Landsat 30 m; LR = 4×
   downsampled bicubic).
6. Apply data augmentation (random horizontal/vertical flips, 90° rotations).
7. Save training, validation, and test split arrays as compressed .npz files.

Usage
-----
    python preprocessing/landsat_preprocess.py \
        --input  data/raw/landsat \
        --output data/processed/landsat

References
----------
USGS Landsat Collection 2: https://earthexplorer.usgs.gov/
"""

import os
import argparse
import logging
from glob import glob
from pathlib import Path

import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.mask import mask as rio_mask
from rasterio.warp import calculate_default_transform, reproject
from rasterio.crs import CRS
from shapely.geometry import box, mapping
from sklearn.model_selection import train_test_split

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LANDSAT, PATCH, STUDY_AREA, PROC_LANDSAT

# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# QA_PIXEL bit flags (Landsat Collection 2 Level-2)
# ---------------------------------------------------------------------------
QA_FILL          = 1 << 0   # bit 0
QA_DILATED_CLOUD = 1 << 1   # bit 1
QA_CIRRUS        = 1 << 2   # bit 2
QA_CLOUD         = 1 << 3   # bit 3
QA_CLOUD_SHADOW  = 1 << 4   # bit 4
QA_SNOW          = 1 << 5   # bit 5
QA_CLEAR         = 1 << 6   # bit 6
QA_WATER         = 1 << 7   # bit 7

MASK_BITS = QA_FILL | QA_CLOUD | QA_CLOUD_SHADOW | QA_CIRRUS | QA_DILATED_CLOUD


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _cloud_fraction(qa_band: np.ndarray) -> float:
    """Return the fraction of masked (cloud / shadow) pixels."""
    valid    = qa_band != 0
    masked   = (qa_band & MASK_BITS).astype(bool)
    if valid.sum() == 0:
        return 1.0
    return float(masked[valid].sum()) / float(valid.sum())


def _apply_scale(data: np.ndarray, nodata: float = 0.0) -> np.ndarray:
    """Apply Landsat Collection 2 scale factor + offset to a single band array."""
    out = data.astype(np.float32)
    valid = out != nodata
    out[valid] = out[valid] * LANDSAT["scale_factor"] + LANDSAT["offset"]
    out[~valid] = np.nan
    # Clamp to [0, 1] — physically valid surface reflectance range
    np.clip(out, 0.0, 1.0, out=out)
    return out


def _reproject_to_utm(src_path: str, dst_path: str) -> None:
    """Reproject a single-band GeoTIFF to EPSG:32638 and clip to study bbox."""
    dst_crs = CRS.from_epsg(STUDY_AREA["epsg"])
    min_lon, min_lat, max_lon, max_lat = STUDY_AREA["bbox_wgs84"]
    clip_geom = [mapping(box(min_lon, min_lat, max_lon, max_lat))]

    with rasterio.open(src_path) as src:
        transform, width, height = calculate_default_transform(
            src.crs, dst_crs, src.width, src.height, *src.bounds
        )
        kwargs = src.meta.copy()
        kwargs.update({
            "crs"      : dst_crs,
            "transform": transform,
            "width"    : width,
            "height"   : height,
            "dtype"    : np.float32,
            "nodata"   : np.nan,
        })
        os.makedirs(os.path.dirname(dst_path), exist_ok=True)
        with rasterio.open(dst_path, "w", **kwargs) as dst:
            for i in range(1, src.count + 1):
                reproject(
                    source      = rasterio.band(src, i),
                    destination = rasterio.band(dst, i),
                    src_transform=src.transform,
                    src_crs     = src.crs,
                    dst_transform=transform,
                    dst_crs     = dst_crs,
                    resampling  = Resampling.bilinear,
                )

    # Clip to bounding box
    with rasterio.open(dst_path) as src:
        # Reproject clip geometry to UTM
        from rasterio.warp import transform_geom
        clip_utm = transform_geom("EPSG:4326", dst_crs.to_wkt(), clip_geom[0])
        out_image, out_transform = rio_mask(src, [clip_utm], crop=True)
        out_meta = src.meta.copy()
        out_meta.update({
            "height"   : out_image.shape[1],
            "width"    : out_image.shape[2],
            "transform": out_transform,
        })
    with rasterio.open(dst_path, "w", **out_meta) as dst:
        dst.write(out_image)


def _extract_patches(
    image: np.ndarray,
    hr_size: int,
    lr_size: int,
    stride: int,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Slide a window over *image* and return paired HR / LR patches.

    Parameters
    ----------
    image   : (H, W, C) float32 in [0, 1]
    hr_size : height/width of high-resolution patch (pixels)
    lr_size : height/width of low-resolution patch (pixels)
    stride  : pixel stride for the sliding window

    Returns
    -------
    hr_patches : (N, hr_size, hr_size, C)
    lr_patches : (N, lr_size, lr_size, C)
    """
    H, W, C = image.shape
    hr_list, lr_list = [], []

    for y in range(0, H - hr_size + 1, stride):
        for x in range(0, W - hr_size + 1, stride):
            hr_patch = image[y:y + hr_size, x:x + hr_size, :]
            # Skip patches with too many NaNs
            if np.isnan(hr_patch).mean() > 0.05:
                continue
            # Replace remaining NaNs with band mean
            for c in range(C):
                ch = hr_patch[:, :, c]
                ch[np.isnan(ch)] = np.nanmean(ch)

            # Downsample HR → LR using area-averaging (bicubic-quality)
            from skimage.transform import resize
            lr_patch = resize(hr_patch, (lr_size, lr_size, C),
                              order=3, anti_aliasing=True,
                              preserve_range=True).astype(np.float32)
            hr_list.append(hr_patch.astype(np.float32))
            lr_list.append(lr_patch)

    return np.stack(hr_list), np.stack(lr_list)


def _augment(hr: np.ndarray, lr: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Apply identical random augmentation to paired HR / LR patches.

    Augmentations: horizontal flip, vertical flip, 0 / 90 / 180 / 270° rotation.
    Returns a dataset 4× the size of the input.
    """
    hr_aug, lr_aug = [hr], [lr]
    # Horizontal flip
    hr_aug.append(hr[:, :, ::-1, :])
    lr_aug.append(lr[:, :, ::-1, :])
    # Vertical flip
    hr_aug.append(hr[:, ::-1, :, :])
    lr_aug.append(lr[:, ::-1, :, :])
    # 90° rotations
    for k in [1, 2, 3]:
        hr_aug.append(np.rot90(hr, k=k, axes=(1, 2)))
        lr_aug.append(np.rot90(lr, k=k, axes=(1, 2)))

    return np.concatenate(hr_aug, axis=0), np.concatenate(lr_aug, axis=0)


# ---------------------------------------------------------------------------
# Main preprocessing function
# ---------------------------------------------------------------------------

def preprocess_scene(scene_dir: str, output_dir: str) -> str | None:
    """
    Preprocess a single Landsat scene directory.

    Expected contents of *scene_dir*:
        *_SR_B2.TIF … *_SR_B7.TIF   — surface reflectance bands
        *_QA_PIXEL.TIF               — quality assessment band

    Returns
    -------
    Path to the stacked, reprojected GeoTIFF, or None if scene was rejected.
    """
    scene_id = os.path.basename(scene_dir)
    band_map  = LANDSAT["bands"]

    # ---- locate QA band ----------------------------------------------------
    qa_files = glob(os.path.join(scene_dir, "*_QA_PIXEL.TIF"))
    if not qa_files:
        log.warning("No QA_PIXEL band found in %s — skipping.", scene_dir)
        return None

    with rasterio.open(qa_files[0]) as qa_src:
        qa_data = qa_src.read(1)
        profile = qa_src.profile

    # ---- cloud fraction check ----------------------------------------------
    cf = _cloud_fraction(qa_data)
    if cf > LANDSAT["cloud_cover"] / 100.0:
        log.info("Scene %s rejected — cloud fraction %.1f%%.", scene_id, cf * 100)
        return None
    log.info("Scene %s accepted — cloud fraction %.1f%%.", scene_id, cf * 100)

    # ---- stack optical bands -----------------------------------------------
    bands_to_read = ["blue", "green", "red", "nir", "swir1", "swir2"]
    stacked = []
    for band_name in bands_to_read:
        pattern = f"*_{band_map[band_name]}.TIF"
        files   = glob(os.path.join(scene_dir, pattern))
        if not files:
            log.warning("Band %s not found in %s — skipping scene.", band_name, scene_dir)
            return None
        with rasterio.open(files[0]) as b_src:
            raw = b_src.read(1).astype(np.float32)
        stacked.append(_apply_scale(raw))

    stacked = np.stack(stacked, axis=0)   # (6, H, W)

    # ---- write temp stacked GeoTIFF ----------------------------------------
    tmp_path = os.path.join(output_dir, f"{scene_id}_stacked_wgs84.tif")
    os.makedirs(output_dir, exist_ok=True)
    profile.update(dtype=np.float32, count=len(bands_to_read), nodata=np.nan)
    with rasterio.open(tmp_path, "w", **profile) as dst:
        dst.write(stacked)

    # ---- reproject to UTM --------------------------------------------------
    utm_path = os.path.join(output_dir, f"{scene_id}_stacked_utm38n.tif")
    _reproject_to_utm(tmp_path, utm_path)
    os.remove(tmp_path)

    return utm_path


def build_patch_dataset(processed_scenes: list[str], output_dir: str) -> None:
    """
    From a list of processed scene GeoTIFFs, extract all patches,
    augment them, split into train / val / test, and save as .npz files.
    """
    hr_size = PATCH["hr_size"]
    lr_size = PATCH["lr_size"]
    stride  = PATCH["stride"]

    all_hr, all_lr = [], []

    for scene_path in processed_scenes:
        log.info("Extracting patches from %s …", os.path.basename(scene_path))
        with rasterio.open(scene_path) as src:
            image = src.read()                        # (C, H, W)
            image = np.transpose(image, (1, 2, 0))    # → (H, W, C)

        hr_patches, lr_patches = _extract_patches(image, hr_size, lr_size, stride)
        all_hr.append(hr_patches)
        all_lr.append(lr_patches)
        log.info("  → %d patches extracted.", len(hr_patches))

    all_hr = np.concatenate(all_hr, axis=0)
    all_lr = np.concatenate(all_lr, axis=0)
    log.info("Total patches before augmentation: %d", len(all_hr))

    # Augment
    if PATCH["augment"]:
        all_hr, all_lr = _augment(all_hr, all_lr)
        log.info("Total patches after augmentation: %d", len(all_hr))

    # Shuffle
    rng = np.random.default_rng(PATCH["random_seed"])
    idx = rng.permutation(len(all_hr))
    all_hr, all_lr = all_hr[idx], all_lr[idx]

    # Split
    n_test  = int(len(all_hr) * PATCH["test_split"])
    n_val   = int(len(all_hr) * PATCH["val_split"])
    n_train = len(all_hr) - n_test - n_val

    splits = {
        "train": (all_lr[:n_train],            all_hr[:n_train]),
        "val"  : (all_lr[n_train:n_train+n_val], all_hr[n_train:n_train+n_val]),
        "test" : (all_lr[n_train+n_val:],       all_hr[n_train+n_val:]),
    }

    os.makedirs(output_dir, exist_ok=True)
    for split_name, (lr_s, hr_s) in splits.items():
        out_path = os.path.join(output_dir, f"patches_{split_name}.npz")
        np.savez_compressed(out_path, lr=lr_s, hr=hr_s)
        log.info("Saved %s split: %d patches → %s", split_name, len(lr_s), out_path)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Preprocess Landsat Collection 2 L2 scenes for super-resolution training."
    )
    parser.add_argument("--input",  default=RAW_LANDSAT,  help="Raw Landsat scene directory.")
    parser.add_argument("--output", default=PROC_LANDSAT, help="Processed output directory.")
    parser.add_argument("--patches_only", action="store_true",
                        help="Skip scene processing; build patches from already-processed TIFFs.")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    if args.patches_only:
        scenes = sorted(glob(os.path.join(args.output, "*_stacked_utm38n.tif")))
    else:
        scene_dirs = sorted([
            d for d in glob(os.path.join(args.input, "*"))
            if os.path.isdir(d)
        ])
        if not scene_dirs:
            log.error("No scene directories found in %s.", args.input)
            return

        log.info("Found %d scene directories.", len(scene_dirs))
        scenes = []
        for scene_dir in scene_dirs:
            result = preprocess_scene(scene_dir, args.output)
            if result:
                scenes.append(result)

    log.info("%d scenes passed quality control.", len(scenes))

    if scenes:
        build_patch_dataset(scenes, args.output)
    else:
        log.warning("No valid scenes to extract patches from.")


if __name__ == "__main__":
    main()
