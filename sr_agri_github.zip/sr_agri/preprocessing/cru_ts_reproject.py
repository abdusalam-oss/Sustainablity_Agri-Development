"""
preprocessing/cru_ts_reproject.py
===================================
CRU-TS v4.05 monthly climate data preprocessing pipeline.

Steps
-----
1. Load CRU-TS NetCDF files for temperature (tmp) and precipitation (pre).
2. Clip to the Al-Qassim bounding box.
3. Reproject from native 0.5° WGS84 grid to 30 m WGS84/UTM 38N using
   bilinear interpolation (via GDAL / rasterio).
4. Export one GeoTIFF per variable per month.
5. Export a combined CSV time series for the region.

Usage
-----
    python preprocessing/cru_ts_reproject.py \
        --input  data/raw/cru_ts \
        --output data/processed/cru_ts

Data source
-----------
Harris, I., Osborn, T.J., Jones, P. et al. (2020).
CRU TS v4.05 — DOI: https://doi.org/10.1038/s41597-020-0453-3
"""

import os
import argparse
import logging
from glob import glob

import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import from_bounds
from rasterio.crs import CRS
from rasterio.warp import reproject as rio_reproject, Resampling, calculate_default_transform
import netCDF4 as nc4

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import CRUTS, STUDY_AREA, PROC_CRUTS

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _decode_time(time_var) -> list[pd.Timestamp]:
    """Decode a NetCDF time variable to a list of pandas Timestamps."""
    try:
        import cftime
        dates = nc4.num2date(time_var[:], units=time_var.units,
                             calendar=getattr(time_var, "calendar", "standard"))
        return [pd.Timestamp(d.year, d.month, 1) for d in dates]
    except Exception:
        # Fallback for 'days since 1900-01-01'
        ref = pd.Timestamp("1900-01-01")
        return [ref + pd.Timedelta(days=int(t)) for t in time_var[:]]


def _clip_to_bbox(data: np.ndarray, lons: np.ndarray, lats: np.ndarray):
    """Return data, sub_lons, sub_lats clipped to STUDY_AREA bbox."""
    min_lon, min_lat, max_lon, max_lat = STUDY_AREA["bbox_wgs84"]
    # CRU-TS lats may be ascending or descending
    lat_asc = lats[0] < lats[-1]
    col_idx = np.where((lons >= min_lon) & (lons <= max_lon))[0]
    row_idx = np.where((lats >= min_lat) & (lats <= max_lat))[0]

    clipped   = data[np.ix_(row_idx, col_idx)]
    sub_lons  = lons[col_idx]
    sub_lats  = lats[row_idx]
    return clipped, sub_lons, sub_lats


def _write_geotiff(
    data: np.ndarray,
    lons: np.ndarray,
    lats: np.ndarray,
    out_path: str,
    nodata: float = -9999.0,
) -> None:
    """Write a 2-D array to a single-band GeoTIFF (WGS84)."""
    res = float(lons[1] - lons[0]) if len(lons) > 1 else CRUTS["resolution_deg"]
    transform = from_bounds(
        west  = float(lons.min())  - res / 2,
        south = float(lats.min())  - res / 2,
        east  = float(lons.max())  + res / 2,
        north = float(lats.max())  + res / 2,
        width = data.shape[1],
        height= data.shape[0],
    )
    arr = np.where(np.isnan(data), nodata, data).astype(np.float32)
    with rasterio.open(
        out_path, "w",
        driver   = "GTiff",
        dtype    = np.float32,
        count    = 1,
        height   = data.shape[0],
        width    = data.shape[1],
        transform= transform,
        crs      = CRS.from_epsg(4326),
        nodata   = nodata,
    ) as dst:
        dst.write(arr[np.newaxis, :, :])


def _reproject_to_utm(src_path: str, dst_path: str) -> None:
    """Reproject a WGS84 GeoTIFF to UTM Zone 38N at Landsat resolution (30 m)."""
    dst_crs = CRS.from_epsg(STUDY_AREA["epsg"])
    with rasterio.open(src_path) as src:
        transform, width, height = calculate_default_transform(
            src.crs, dst_crs, src.width, src.height, *src.bounds
        )
        kwargs = src.meta.copy()
        kwargs.update({"crs": dst_crs, "transform": transform,
                       "width": width, "height": height})
        with rasterio.open(dst_path, "w", **kwargs) as dst:
            for i in range(1, src.count + 1):
                rio_reproject(
                    source      = rasterio.band(src, i),
                    destination = rasterio.band(dst, i),
                    src_transform=src.transform,
                    src_crs     = src.crs,
                    dst_transform=transform,
                    dst_crs     = dst_crs,
                    resampling  = Resampling.bilinear,
                )


# ---------------------------------------------------------------------------
# Main processing
# ---------------------------------------------------------------------------

def process_cruts_variable(nc_path: str, variable: str, output_dir: str) -> pd.DataFrame:
    """
    Process a single CRU-TS NetCDF file for one variable.

    Returns a DataFrame with monthly regional statistics.
    """
    os.makedirs(output_dir, exist_ok=True)
    records = []

    with nc4.Dataset(nc_path, "r") as ds:
        if variable not in ds.variables:
            log.error("Variable '%s' not found in %s.", variable, nc_path)
            return pd.DataFrame()

        lons  = np.array(ds.variables["lon"][:])
        lats  = np.array(ds.variables["lat"][:])
        dates = _decode_time(ds.variables["time"])
        data_var = ds.variables[variable]
        fill_val = getattr(data_var, "_FillValue", -9999.0)
        units    = getattr(data_var, "units", "")

        log.info("Processing CRU-TS variable '%s' (%d months) …", variable, len(dates))

        for t_idx, date in enumerate(dates):
            if date.year < CRUTS["start_year"] or date.year > CRUTS["end_year"]:
                continue

            data = np.array(data_var[t_idx, :, :], dtype=np.float32)
            data[data == fill_val] = np.nan

            # Clip to bbox
            clipped, sub_lons, sub_lats = _clip_to_bbox(data, lons, lats)
            date_str = date.strftime("%Y-%m")

            # Write WGS84 GeoTIFF
            wgs_path = os.path.join(output_dir, f"{variable}_{date_str}_wgs84.tif")
            _write_geotiff(clipped, sub_lons, sub_lats, wgs_path)

            # Reproject to UTM 38N
            utm_path = os.path.join(output_dir, f"{variable}_{date_str}_utm38n.tif")
            _reproject_to_utm(wgs_path, utm_path)
            os.remove(wgs_path)   # keep only UTM version

            # Regional statistics
            valid_vals = clipped[~np.isnan(clipped)]
            records.append({
                "date"       : date_str,
                "variable"   : variable,
                "units"      : units,
                "mean"       : float(np.nanmean(valid_vals)) if len(valid_vals) else np.nan,
                "std"        : float(np.nanstd(valid_vals))  if len(valid_vals) else np.nan,
                "min"        : float(np.nanmin(valid_vals))  if len(valid_vals) else np.nan,
                "max"        : float(np.nanmax(valid_vals))  if len(valid_vals) else np.nan,
                "n_valid"    : int(len(valid_vals)),
            })

            if t_idx % 60 == 0:
                log.info("  … %s %s processed.", variable, date_str)

    df = pd.DataFrame(records).sort_values("date").reset_index(drop=True)
    csv_out = os.path.join(output_dir, f"cruts_{variable}_alqassim_timeseries.csv")
    df.to_csv(csv_out, index=False)
    log.info("Saved CRU-TS '%s' time series (%d months) → %s", variable, len(df), csv_out)
    return df


def process_all(input_dir: str, output_dir: str) -> None:
    for variable in CRUTS["variables"]:
        pattern = os.path.join(input_dir, f"cru_ts*.{variable}.nc")
        nc_files = sorted(glob(pattern))
        if not nc_files:
            log.warning("No CRU-TS file for variable '%s' found (pattern: %s).", variable, pattern)
            continue
        for nc_path in nc_files:
            log.info("Processing file: %s", os.path.basename(nc_path))
            process_cruts_variable(nc_path, variable, output_dir)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Preprocess CRU-TS v4.05 monthly climate data."
    )
    parser.add_argument("--input",  default=os.path.join(os.path.dirname(os.path.dirname(
                                        os.path.abspath(__file__))), "data", "raw", "cru_ts"),
                        help="Directory containing CRU-TS .nc files.")
    parser.add_argument("--output", default=PROC_CRUTS,
                        help="Output directory for reprojected GeoTIFFs and CSVs.")
    args = parser.parse_args()
    process_all(args.input, args.output)


if __name__ == "__main__":
    main()
