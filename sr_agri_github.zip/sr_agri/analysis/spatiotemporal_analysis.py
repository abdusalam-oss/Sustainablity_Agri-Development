"""
analysis/spatiotemporal_analysis.py
=====================================
Spatiotemporal analysis of vegetation indices and climate variables.

Implements all methods described in the paper's methodology section:

Change detection   (Equation  8) : ΔNDVI(t1, t2) = NDVI_t2 − NDVI_t1
Time-series trend  (Equation  9) : NDVI(t) = β0 + β1·t + ε
Moran's I          (Equation 10) : spatial autocorrelation
Spatiotemporal     (Equation 11) : Kriging interpolation
Fourier analysis   (Equation 12) : F(ω) = ∫ f(t) e^{-iωt} dt

Usage
-----
    python analysis/spatiotemporal_analysis.py \
        --indices  results/indices \
        --climate  data/processed \
        --output   results/analysis
"""

import os
import argparse
import logging
from glob import glob

import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import from_bounds
from scipy import stats as scipy_stats
from scipy.fft import fft, fftfreq

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import ANALYSIS, RES_INDICES, RES_ANALYSIS, PROC_CRUTS, PROC_GRACE

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Change detection (Eq. 8)
# ---------------------------------------------------------------------------

def change_detection(
    tif_t1: str,
    tif_t2: str,
    output_path: str,
) -> np.ndarray:
    """
    Compute pixel-wise change between two single-band vegetation index GeoTIFFs.

    Returns the change array (ΔNDVI = t2 − t1) and saves it as a GeoTIFF.
    """
    with rasterio.open(tif_t1) as src1:
        arr1 = src1.read(1).astype(np.float32)
        meta = src1.meta.copy()
    with rasterio.open(tif_t2) as src2:
        arr2 = src2.read(1).astype(np.float32)

    delta = arr2 - arr1

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    meta.update({"dtype": np.float32, "nodata": np.nan})
    with rasterio.open(output_path, "w", **meta) as dst:
        dst.write(delta[np.newaxis, :, :])

    log.info("Change map saved → %s  (mean Δ = %.4f)", output_path, np.nanmean(delta))
    return delta


# ---------------------------------------------------------------------------
# Time-series linear trend (Eq. 9)
# ---------------------------------------------------------------------------

def pixel_wise_trend(
    index_series: list[tuple[str, np.ndarray]],
) -> dict[str, np.ndarray]:
    """
    Fit a linear trend to a time series of 2-D index arrays.

    Parameters
    ----------
    index_series : list of (date_str, 2D array) tuples, sorted by date

    Returns
    -------
    dict with keys 'slope', 'intercept', 'r_value', 'p_value', 'std_err'
    — each a 2-D array of the same spatial dimensions.
    """
    if len(index_series) < 3:
        raise ValueError("Need at least 3 time steps for trend analysis.")

    t_values = np.arange(len(index_series), dtype=np.float64)
    ref_shape = index_series[0][1].shape
    stack     = np.stack([arr for _, arr in index_series], axis=0)   # (T, H, W)
    T, H, W   = stack.shape

    slope     = np.full((H, W), np.nan, dtype=np.float32)
    intercept = np.full((H, W), np.nan, dtype=np.float32)
    r_value   = np.full((H, W), np.nan, dtype=np.float32)
    p_value   = np.full((H, W), np.nan, dtype=np.float32)
    std_err   = np.full((H, W), np.nan, dtype=np.float32)

    log.info("Computing pixel-wise linear trend for %d time steps (%d×%d) …",
             T, H, W)
    for row in range(H):
        for col in range(W):
            y = stack[:, row, col]
            valid = ~np.isnan(y)
            if valid.sum() < 3:
                continue
            res = scipy_stats.linregress(t_values[valid], y[valid])
            slope[row, col]     = res.slope
            intercept[row, col] = res.intercept
            r_value[row, col]   = res.rvalue
            p_value[row, col]   = res.pvalue
            std_err[row, col]   = res.stderr

    return {
        "slope"    : slope,
        "intercept": intercept,
        "r_value"  : r_value,
        "p_value"  : p_value,
        "std_err"  : std_err,
    }


def regional_trend_from_csv(
    vi_csv: str,
    column: str,
    date_column: str = "date",
) -> dict:
    """
    Fit a linear trend to a regional mean time series loaded from CSV.

    Returns
    -------
    dict with slope, intercept, r, p, std_err, n
    """
    df = pd.read_csv(vi_csv, parse_dates=[date_column])
    df = df.sort_values(date_column).reset_index(drop=True)
    df = df.dropna(subset=[column])

    t = np.arange(len(df), dtype=np.float64)
    y = df[column].values.astype(np.float64)

    res = scipy_stats.linregress(t, y)
    result = {
        "slope"    : float(res.slope),
        "intercept": float(res.intercept),
        "r"        : float(res.rvalue),
        "p_value"  : float(res.pvalue),
        "std_err"  : float(res.stderr),
        "n"        : int(len(y)),
        "variable" : column,
        "date_start": str(df[date_column].iloc[0].date()),
        "date_end"  : str(df[date_column].iloc[-1].date()),
    }
    log.info(
        "Trend [%s]: slope=%.6f, r=%.3f, p=%.4f (n=%d)",
        column, result["slope"], result["r"], result["p_value"], result["n"],
    )
    return result


# ---------------------------------------------------------------------------
# Moran's I spatial autocorrelation (Eq. 10)
# ---------------------------------------------------------------------------

def morans_i(
    arr: np.ndarray,
    queen: bool = True,
) -> dict:
    """
    Compute Moran's I for a 2-D array using Queen or Rook contiguity.

    Parameters
    ----------
    arr   : 2-D float array (NaN values are excluded)
    queen : True for Queen (8-neighbour), False for Rook (4-neighbour)

    Returns
    -------
    dict with keys 'I', 'E_I', 'z_score', 'p_value'
    """
    H, W   = arr.shape
    valid  = ~np.isnan(arr)
    coords = np.argwhere(valid)
    values = arr[valid]
    N      = len(values)

    if N < 4:
        return {"I": np.nan, "E_I": np.nan, "z_score": np.nan, "p_value": np.nan}

    mean_x = values.mean()
    deviations = values - mean_x

    # Build spatial weight matrix (Queen / Rook contiguity)
    # For efficiency we use a dict of sets
    W_sum   = 0.0
    num     = 0.0
    denom   = float(np.sum(deviations ** 2))

    coord_to_idx = {tuple(c): i for i, c in enumerate(coords)}

    if queen:
        neighbours_offsets = [(-1,-1),(-1,0),(-1,1),
                               (0,-1),        (0,1),
                               (1,-1),(1,0),  (1,1)]
    else:
        neighbours_offsets = [(-1,0),(0,-1),(0,1),(1,0)]

    for i, (r, c) in enumerate(coords):
        for dr, dc in neighbours_offsets:
            nb = (r + dr, c + dc)
            if nb in coord_to_idx:
                j = coord_to_idx[nb]
                num   += deviations[i] * deviations[j]
                W_sum += 1.0

    if W_sum == 0 or denom == 0:
        return {"I": np.nan, "E_I": np.nan, "z_score": np.nan, "p_value": np.nan}

    I   = (N / W_sum) * (num / denom)
    E_I = -1.0 / (N - 1)

    # Variance approximation under normality assumption
    var_I = (N * ((N**2 - 3*N + 3) * W_sum - N * W_sum + 3 * W_sum**2)) / \
            (denom**2 * (N-1) * (N-2) * (N-3) * W_sum**2 + 1e-10) - E_I**2

    z     = (I - E_I) / (np.sqrt(abs(var_I)) + 1e-10)
    p_val = 2.0 * (1.0 - scipy_stats.norm.cdf(abs(z)))

    log.info("Moran's I = %.4f (E[I]=%.4f, z=%.2f, p=%.4f, N=%d)", I, E_I, z, p_val, N)
    return {"I": float(I), "E_I": float(E_I), "z_score": float(z), "p_value": float(p_val)}


# ---------------------------------------------------------------------------
# Spatiotemporal Kriging (simplified; Eq. 11)
# ---------------------------------------------------------------------------

def spatiotemporal_kriging_1d(
    obs_times: np.ndarray,
    obs_values: np.ndarray,
    pred_times: np.ndarray,
) -> np.ndarray:
    """
    Simple 1-D (temporal) ordinary Kriging for a regional mean time series.

    Variogram model: spherical with automatic parameter estimation.

    Parameters
    ----------
    obs_times   : 1-D array of observation time indices
    obs_values  : 1-D array of observed values
    pred_times  : 1-D array of prediction time indices

    Returns
    -------
    pred_values : 1-D array of Kriged predictions at pred_times
    """
    n  = len(obs_times)
    # Estimate variogram parameters via method of moments (simplified)
    # Use spherical model: γ(h) = c0 + c1 [1.5(h/a) - 0.5(h/a)³] for h ≤ a
    #                             c0 + c1                           for h > a
    lags   = np.abs(obs_times[:, None] - obs_times[None, :])       # (n, n)
    diffs  = (obs_values[:, None] - obs_values[None, :]) ** 2
    with np.errstate(divide="ignore", invalid="ignore"):
        gamma_exp = np.where(lags > 0, 0.5 * diffs, 0.0)           # experimental semivariogram

    lag_bins   = np.unique(lags)
    gamma_bins = [gamma_exp[lags == l].mean() for l in lag_bins]

    # Fit: nugget c0, sill c0+c1, range a
    c0 = float(gamma_bins[1]) if len(gamma_bins) > 1 else 0.0
    c1 = float(max(gamma_bins)) - c0
    a  = float(lag_bins[len(lag_bins)//2]) if len(lag_bins) > 2 else 1.0

    def spherical(h, c0, c1, a):
        h = np.asarray(h, dtype=float)
        g = np.where(
            h == 0, 0.0,
            np.where(h <= a,
                     c0 + c1 * (1.5 * h/a - 0.5 * (h/a)**3),
                     c0 + c1)
        )
        return g

    # Build kriging system
    C  = spherical(lags, c0, c1, a)                                 # (n, n)
    # Add nugget to diagonal for numerical stability
    C += np.eye(n) * c0 * 1e-6
    # Augment for unbiasedness constraint
    A  = np.block([[C,         np.ones((n, 1))],
                   [np.ones((1, n)), np.array([[0.0]])]])

    pred_values = np.zeros(len(pred_times), dtype=np.float64)
    for k, t_pred in enumerate(pred_times):
        h_pred = np.abs(obs_times - t_pred)
        c0_vec = spherical(h_pred, c0, c1, a)                       # (n,)
        b      = np.append(c0_vec, 1.0)
        try:
            weights = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            weights = np.zeros(n + 1)
        pred_values[k] = float(np.dot(weights[:n], obs_values))

    return pred_values


# ---------------------------------------------------------------------------
# Fourier analysis (Eq. 12)
# ---------------------------------------------------------------------------

def fourier_analysis(
    time_series: np.ndarray,
    dt: float = 1.0,
    min_period: float | None = None,
) -> pd.DataFrame:
    """
    Perform Fourier analysis on a 1-D time series.

    Parameters
    ----------
    time_series : 1-D float array (evenly spaced, NaN will be linearly interpolated)
    dt          : time step between samples (e.g. 1.0 for monthly data)
    min_period  : minimum period to report (in same units as dt)

    Returns
    -------
    DataFrame with columns [frequency, period, amplitude, power] sorted by power desc.
    """
    ts = pd.Series(time_series.copy())
    ts = ts.interpolate(method="linear").fillna(method="bfill").fillna(method="ffill")
    y  = ts.values.astype(np.float64)
    N  = len(y)

    # Remove mean (trend would require STL first — see trend_correlation.py)
    y -= y.mean()

    # FFT
    Y   = fft(y)
    freqs = fftfreq(N, d=dt)

    # One-sided spectrum
    pos_mask   = freqs > 0
    freqs_pos  = freqs[pos_mask]
    amplitude  = (2.0 / N) * np.abs(Y[pos_mask])
    power      = amplitude ** 2
    period     = np.where(freqs_pos > 0, 1.0 / freqs_pos, np.inf)

    df = pd.DataFrame({
        "frequency": freqs_pos,
        "period"   : period,
        "amplitude": amplitude,
        "power"    : power,
    }).sort_values("power", ascending=False).reset_index(drop=True)

    if min_period is not None:
        df = df[df["period"] >= min_period]

    return df


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def run_full_analysis(
    vi_csv: str,
    grace_csv: str,
    climate_tmp_csv: str,
    climate_pre_csv: str,
    output_dir: str,
) -> None:
    """
    Run all spatiotemporal analyses and save results to *output_dir*.
    """
    os.makedirs(output_dir, exist_ok=True)
    results = {}

    # ---- Load VI time series -----------------------------------------------
    vi = pd.read_csv(vi_csv)
    if "date" in vi.columns:
        vi["date"] = pd.to_datetime(vi["date"])
        vi = vi.sort_values("date").reset_index(drop=True)

    vi_cols = [c for c in vi.columns if c.endswith("_mean")]
    log.info("Vegetation index columns found: %s", vi_cols)

    # ---- Linear trends on regional means ------------------------------------
    trend_records = []
    for col in vi_cols:
        if col not in vi.columns:
            continue
        t = np.arange(len(vi), dtype=np.float64)
        y = vi[col].values.astype(np.float64)
        valid = ~np.isnan(y)
        if valid.sum() < 3:
            continue
        res = scipy_stats.linregress(t[valid], y[valid])
        trend_records.append({
            "variable" : col,
            "slope"    : float(res.slope),
            "intercept": float(res.intercept),
            "r"        : float(res.rvalue),
            "p_value"  : float(res.pvalue),
            "n"        : int(valid.sum()),
        })
        log.info("Trend [%s]: slope=%.6f, r=%.3f, p=%.4f", col,
                 res.slope, res.rvalue, res.pvalue)

    trend_df = pd.DataFrame(trend_records)
    trend_df.to_csv(os.path.join(output_dir, "trend_analysis.csv"), index=False)
    log.info("Trend analysis saved.")

    # ---- Fourier analysis on NDVI mean ----------------------------------------
    if "ndvi_mean" in vi.columns:
        fa_df = fourier_analysis(
            vi["ndvi_mean"].values,
            dt=1.0,
            min_period=ANALYSIS["fourier_min_period_months"],
        )
        fa_df.to_csv(os.path.join(output_dir, "fourier_ndvi.csv"), index=False)
        log.info("Top Fourier components (NDVI):\n%s", fa_df.head(5).to_string())

    # ---- Moran's I on most recent NDVI raster (if available) ------------------
    ndvi_tifs = sorted(glob(os.path.join(os.path.dirname(vi_csv), "*_ndvi.tif")))
    if ndvi_tifs:
        with rasterio.open(ndvi_tifs[-1]) as src:
            arr = src.read(1).astype(np.float32)
        mi = morans_i(arr, queen=ANALYSIS["morans_queen"])
        mi["raster"] = os.path.basename(ndvi_tifs[-1])
        pd.DataFrame([mi]).to_csv(
            os.path.join(output_dir, "morans_i.csv"), index=False)
        log.info("Moran's I: I=%.4f, p=%.4f", mi["I"], mi["p_value"])

    log.info("Spatiotemporal analysis complete. Results in %s", output_dir)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Spatiotemporal analysis of VI and climate data.")
    parser.add_argument("--indices",    default=RES_INDICES)
    parser.add_argument("--climate",    default=PROC_CRUTS)
    parser.add_argument("--grace",      default=os.path.join(PROC_GRACE,
                                            "grace_tws_alqassim_timeseries.csv"))
    parser.add_argument("--output",     default=RES_ANALYSIS)
    args = parser.parse_args()

    vi_csv        = os.path.join(args.indices, "vegetation_indices_timeseries.csv")
    tmp_csv       = os.path.join(args.climate, "cruts_tmp_alqassim_timeseries.csv")
    pre_csv       = os.path.join(args.climate, "cruts_pre_alqassim_timeseries.csv")

    run_full_analysis(vi_csv, args.grace, tmp_csv, pre_csv, args.output)


if __name__ == "__main__":
    main()
