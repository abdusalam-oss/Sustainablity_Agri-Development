"""
analysis/validation.py
========================
Validation metrics and k-fold cross-validation for super-resolution models.

Metrics implemented (Equations 18–23 in the paper)
---------------------------------------------------
RMSE      (Eq. 18): √[1/n Σ(P_i − O_i)²]
MAE       (Eq. 19): 1/n Σ|P_i − O_i|
R²        (Eq. 20): 1 − Σ(O_i−P_i)² / Σ(O_i−Ō)²
SSIM      (Eq. 21): structural similarity index
PSNR      (Eq. 22): 20 log10(MAX_I / √MSE)
CV-score  (Eq. 23): 1/k Σ Metric(M_i)

Usage
-----
    python analysis/validation.py \
        --predicted results/srgan \
        --reference data/processed/planetscope \
        --output    results/analysis
"""

import os
import argparse
import logging
import json
from glob import glob

import numpy as np
import pandas as pd
import rasterio
from skimage.metrics import structural_similarity as ssim_fn
from skimage.metrics import peak_signal_noise_ratio as psnr_fn
from sklearn.model_selection import KFold

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import ANALYSIS, RES_SRGAN, RES_ANALYSIS, PROC_LANDSAT

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core metric functions
# ---------------------------------------------------------------------------

def rmse(predicted: np.ndarray, observed: np.ndarray) -> float:
    """Root Mean Square Error (Equation 18)."""
    return float(np.sqrt(np.mean((predicted - observed) ** 2)))


def mae(predicted: np.ndarray, observed: np.ndarray) -> float:
    """Mean Absolute Error (Equation 19)."""
    return float(np.mean(np.abs(predicted - observed)))


def r_squared(predicted: np.ndarray, observed: np.ndarray) -> float:
    """Coefficient of Determination R² (Equation 20)."""
    ss_res = np.sum((observed - predicted) ** 2)
    ss_tot = np.sum((observed - observed.mean()) ** 2)
    if ss_tot == 0:
        return np.nan
    return float(1.0 - ss_res / ss_tot)


def ssim(
    predicted: np.ndarray,
    observed: np.ndarray,
    data_range: float = 1.0,
    channel_axis: int | None = -1,
) -> float:
    """
    Structural Similarity Index (Equation 21).

    For multi-band images, SSIM is computed channel-wise and averaged.
    """
    if predicted.ndim == 2:
        return float(ssim_fn(observed, predicted, data_range=data_range))
    # Multi-band: average over channels
    n_channels = predicted.shape[-1]
    ssim_vals  = [
        ssim_fn(observed[:, :, c], predicted[:, :, c], data_range=data_range)
        for c in range(n_channels)
    ]
    return float(np.mean(ssim_vals))


def psnr(
    predicted: np.ndarray,
    observed: np.ndarray,
    data_range: float = 1.0,
) -> float:
    """
    Peak Signal-to-Noise Ratio (Equation 22).

    PSNR = 20 log10(MAX_I / √MSE)
    """
    if predicted.ndim == 2:
        return float(psnr_fn(observed, predicted, data_range=data_range))
    # Multi-band: average over channels
    n_channels = predicted.shape[-1]
    psnr_vals  = [
        psnr_fn(observed[:, :, c], predicted[:, :, c], data_range=data_range)
        for c in range(n_channels)
    ]
    return float(np.mean(psnr_vals))


def all_metrics(
    predicted: np.ndarray,
    observed: np.ndarray,
    data_range: float = 1.0,
) -> dict:
    """Compute RMSE, MAE, R², SSIM, PSNR in one call."""
    p = predicted.astype(np.float32)
    o = observed.astype(np.float32)
    return {
        "rmse": rmse(p, o),
        "mae" : mae(p, o),
        "r2"  : r_squared(p.ravel(), o.ravel()),
        "ssim": ssim(p, o, data_range=data_range),
        "psnr": psnr(p, o, data_range=data_range),
    }


# ---------------------------------------------------------------------------
# Patch-level evaluation
# ---------------------------------------------------------------------------

def evaluate_patch_set(
    data_dir: str,
    split: str = "test",
    model_type: str = "srgan",
) -> pd.DataFrame:
    """
    Load predicted SR patches and HR reference patches, compute metrics per patch.

    Expects:
      - data_dir/patches_{split}.npz            — HR reference patches
      - data_dir/{model_type}_predictions.npz  — SR predictions (same order)

    Returns DataFrame with one row per patch.
    """
    hr_npz   = os.path.join(data_dir, f"patches_{split}.npz")
    pred_npz = os.path.join(data_dir, f"{model_type}_predictions_{split}.npz")

    if not os.path.exists(hr_npz):
        raise FileNotFoundError(f"Reference patches not found: {hr_npz}")
    if not os.path.exists(pred_npz):
        raise FileNotFoundError(
            f"Predicted patches not found: {pred_npz}. "
            f"Run the model evaluation script first."
        )

    hr_data   = np.load(hr_npz)["hr"].astype(np.float32)
    pred_data = np.load(pred_npz)["sr"].astype(np.float32)

    assert len(hr_data) == len(pred_data), (
        f"Mismatch: {len(hr_data)} reference vs {len(pred_data)} predicted patches."
    )

    records = []
    for i in range(len(hr_data)):
        m = all_metrics(pred_data[i], hr_data[i])
        records.append(m)

    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# K-fold cross-validation (Equation 23)
# ---------------------------------------------------------------------------

def kfold_cross_validate(
    lr_patches: np.ndarray,
    hr_patches: np.ndarray,
    model_fn,
    k: int = 5,
    metric: str = "psnr",
) -> dict:
    """
    Run k-fold cross-validation on a super-resolution model.

    Parameters
    ----------
    lr_patches : (N, H_lr, W_lr, C) array of low-resolution patches
    hr_patches : (N, H_hr, W_hr, C) array of high-resolution patches
    model_fn   : callable(lr_train, hr_train, lr_val, hr_val) → predictions on lr_val
    k          : number of folds
    metric     : metric to aggregate ('rmse', 'mae', 'r2', 'ssim', 'psnr')

    Returns
    -------
    dict with keys: fold_scores, mean, std, metric
    """
    kf     = KFold(n_splits=k, shuffle=True, random_state=ANALYSIS["kfold_splits"])
    scores = []

    for fold, (train_idx, val_idx) in enumerate(kf.split(lr_patches)):
        lr_train, hr_train = lr_patches[train_idx], hr_patches[train_idx]
        lr_val,   hr_val   = lr_patches[val_idx],   hr_patches[val_idx]

        log.info("Fold %d/%d — train: %d, val: %d", fold + 1, k,
                 len(lr_train), len(lr_val))
        sr_val = model_fn(lr_train, hr_train, lr_val, hr_val)
        sr_val = np.clip(sr_val.astype(np.float32), 0.0, 1.0)

        fold_metrics = [all_metrics(sr_val[i], hr_val[i]) for i in range(len(hr_val))]
        fold_score   = float(np.mean([m[metric] for m in fold_metrics]))
        scores.append(fold_score)
        log.info("  Fold %d %s = %.4f", fold + 1, metric.upper(), fold_score)

    cv_score = float(np.mean(scores))
    cv_std   = float(np.std(scores))
    log.info("CV Score (%s): %.4f ± %.4f", metric.upper(), cv_score, cv_std)

    return {
        "fold_scores": scores,
        "mean"       : cv_score,
        "std"        : cv_std,
        "metric"     : metric,
        "k"          : k,
    }


# ---------------------------------------------------------------------------
# PlanetScope validation
# ---------------------------------------------------------------------------

def validate_against_planetscope(
    sr_tif: str,
    ps_reference_tif: str,
    output_dir: str,
) -> dict:
    """
    Validate a full-scene SR GeoTIFF against a co-registered PlanetScope reference.

    Both images must have the same spatial extent and CRS.

    Returns
    -------
    dict of validation metrics
    """
    os.makedirs(output_dir, exist_ok=True)

    with rasterio.open(sr_tif) as src_sr:
        sr_data = src_sr.read().astype(np.float32)     # (C, H, W)
    with rasterio.open(ps_reference_tif) as src_ps:
        ps_data = src_ps.read().astype(np.float32)

    # Ensure same shape (crop to minimum common extent)
    min_bands = min(sr_data.shape[0], ps_data.shape[0])
    min_h     = min(sr_data.shape[1], ps_data.shape[1])
    min_w     = min(sr_data.shape[2], ps_data.shape[2])
    sr_crop   = sr_data[:min_bands, :min_h, :min_w]
    ps_crop   = ps_data[:min_bands, :min_h, :min_w]

    # Normalise to [0, 1] if needed
    if ps_crop.max() > 2.0:
        ps_crop = ps_crop / 10000.0   # Planet DN to reflectance approximation

    # Transpose to (H, W, C) for metric functions
    sr_hwc = np.transpose(sr_crop, (1, 2, 0))
    ps_hwc = np.transpose(ps_crop, (1, 2, 0))

    m = all_metrics(sr_hwc, ps_hwc)
    m["sr_tif"]  = os.path.basename(sr_tif)
    m["ref_tif"] = os.path.basename(ps_reference_tif)

    log.info(
        "PlanetScope validation — RMSE=%.4f | MAE=%.4f | R²=%.4f | "
        "PSNR=%.2f dB | SSIM=%.4f",
        m["rmse"], m["mae"], m["r2"], m["psnr"], m["ssim"],
    )

    out_json = os.path.join(output_dir, "planetscope_validation.json")
    with open(out_json, "w") as f:
        json.dump(m, f, indent=2)

    return m


# ---------------------------------------------------------------------------
# Comparison table across all three models
# ---------------------------------------------------------------------------

def model_comparison_table(
    data_dir: str,
    output_dir: str,
) -> pd.DataFrame:
    """
    Build a comparison table (RMSE, PSNR, SSIM) for Bicubic, SRCNN, SRGAN
    on the shared test patch set.

    Looks for per-model metric CSVs produced during evaluation:
        data_dir/bicubic_metrics_per_patch.csv
        data_dir/srcnn_metrics_per_patch.csv
        data_dir/srgan_metrics_per_patch.csv
    """
    os.makedirs(output_dir, exist_ok=True)
    models  = ["bicubic", "srcnn", "srgan"]
    rows    = []

    for model in models:
        csv_path = os.path.join(data_dir, f"{model}_metrics_per_patch.csv")
        if not os.path.exists(csv_path):
            # Try in dedicated result subdirs
            from config import RES_BICUBIC, RES_SRCNN, RES_SRGAN
            subdir   = {"bicubic": RES_BICUBIC, "srcnn": RES_SRCNN, "srgan": RES_SRGAN}[model]
            csv_path = os.path.join(subdir, f"{model}_metrics_per_patch.csv")

        if not os.path.exists(csv_path):
            log.warning("Metric CSV not found for model '%s' — skipping.", model)
            continue

        df   = pd.read_csv(csv_path)
        mean = df[["rmse", "psnr", "ssim"]].mean()
        std  = df[["rmse", "psnr", "ssim"]].std()
        rows.append({
            "Model"      : model.upper(),
            "RMSE_mean"  : round(float(mean["rmse"]), 4),
            "RMSE_std"   : round(float(std["rmse"]),  4),
            "PSNR_mean"  : round(float(mean["psnr"]), 2),
            "PSNR_std"   : round(float(std["psnr"]),  2),
            "SSIM_mean"  : round(float(mean["ssim"]), 4),
            "SSIM_std"   : round(float(std["ssim"]),  4),
            "n_patches"  : len(df),
        })
        log.info(
            "%-10s RMSE=%.4f±%.4f | PSNR=%.2f±%.2f dB | SSIM=%.4f±%.4f",
            model.upper(),
            float(mean["rmse"]), float(std["rmse"]),
            float(mean["psnr"]), float(std["psnr"]),
            float(mean["ssim"]), float(std["ssim"]),
        )

    cmp_df   = pd.DataFrame(rows)
    cmp_csv  = os.path.join(output_dir, "model_comparison.csv")
    cmp_df.to_csv(cmp_csv, index=False)
    log.info("Model comparison table saved → %s", cmp_csv)
    return cmp_df


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Validate SR outputs and compare model performance."
    )
    parser.add_argument("--predicted",  default=RES_SRGAN,
                        help="Directory containing SR predictions / metric CSVs.")
    parser.add_argument("--reference",  default=None,
                        help="PlanetScope reference GeoTIFF for scene-level validation.")
    parser.add_argument("--sr_scene",   default=None,
                        help="SR GeoTIFF scene for PlanetScope validation.")
    parser.add_argument("--output",     default=RES_ANALYSIS)
    parser.add_argument("--compare",    action="store_true",
                        help="Build model comparison table.")
    args = parser.parse_args()

    if args.compare:
        model_comparison_table(args.predicted, args.output)

    if args.reference and args.sr_scene:
        validate_against_planetscope(args.sr_scene, args.reference, args.output)

    if not args.compare and not args.reference:
        # Default: build model comparison table
        model_comparison_table(args.predicted, args.output)


if __name__ == "__main__":
    main()
