"""
analysis/trend_correlation.py
================================
Trend and correlation analysis between vegetation indices and climatic variables.

Implements all methods described in the paper's methodology section:

Linear trend (Eq. 13):    Y_t = β0 + β1·t + ε_t
STL decomposition (Eq. 14): Y_t = T_t + S_t + R_t
Pearson's r (Eq. 15):     r  = Σ(Xi-X̄)(Yi-Ȳ) / [√Σ(Xi-X̄)² · √Σ(Yi-Ȳ)²]
Spearman's ρ (Eq. 16):    ρ  = 1 − 6Σd²_i / [n(n²−1)]
ACF (Eq. 17):             ρk = Σ(Y_t−Ȳ)(Y_{t+k}−Ȳ) / Σ(Y_t−Ȳ)²

Usage
-----
    python analysis/trend_correlation.py \
        --indices  results/indices \
        --climate  data/processed \
        --output   results/analysis
"""

import os
import argparse
import logging
from itertools import product

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats
from statsmodels.tsa.seasonal import STL

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import ANALYSIS, RES_INDICES, RES_ANALYSIS, PROC_CRUTS, PROC_GRACE, PROC_PME

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_monthly_csv(csv_path: str, value_col: str, date_col: str = "date") -> pd.Series:
    """Load a monthly CSV and return a DatetimeIndex Series."""
    df = pd.read_csv(csv_path, parse_dates=[date_col])
    df = df.sort_values(date_col).set_index(date_col)
    return df[value_col].astype(float)


def _align_series(*series_list) -> pd.DataFrame:
    """Align multiple Series on their common DatetimeIndex (inner join)."""
    df = pd.concat(series_list, axis=1, join="inner")
    return df.dropna()


# ---------------------------------------------------------------------------
# Linear trend (Eq. 13)
# ---------------------------------------------------------------------------

def linear_trend(series: pd.Series) -> dict:
    """
    Fit Y_t = β0 + β1·t + ε_t to a pandas Series indexed by time.

    Returns dict with slope (β1), intercept (β0), r², p_value, std_err.
    """
    y = series.dropna().values.astype(np.float64)
    t = np.arange(len(y), dtype=np.float64)
    res = scipy_stats.linregress(t, y)
    return {
        "slope"    : float(res.slope),
        "intercept": float(res.intercept),
        "r2"       : float(res.rvalue ** 2),
        "p_value"  : float(res.pvalue),
        "std_err"  : float(res.stderr),
        "n"        : int(len(y)),
    }


# ---------------------------------------------------------------------------
# STL decomposition (Eq. 14)
# ---------------------------------------------------------------------------

def stl_decompose(
    series: pd.Series,
    period: int = 12,
    seasonal: int = 13,
) -> pd.DataFrame:
    """
    Decompose Y_t = T_t + S_t + R_t using STL.

    Parameters
    ----------
    series   : monthly time series (DatetimeIndex), NaN will be interpolated
    period   : periodicity (12 for monthly data)
    seasonal : length of seasonal smoother (must be odd, ≥ 7)

    Returns
    -------
    DataFrame with columns [observed, trend, seasonal, residual]
    """
    s = series.copy().interpolate("linear").fillna(method="bfill")
    if len(s) < 2 * period:
        log.warning("STL requires at least 2 full periods. Returning NaN decomposition.")
        return pd.DataFrame({
            "observed": s,
            "trend"   : np.nan,
            "seasonal": np.nan,
            "residual": np.nan,
        })

    stl    = STL(s, period=period, seasonal=seasonal)
    result = stl.fit()
    df = pd.DataFrame({
        "observed": result.observed,
        "trend"   : result.trend,
        "seasonal": result.seasonal,
        "residual": result.resid,
    }, index=s.index)
    return df


# ---------------------------------------------------------------------------
# Pearson's r (Eq. 15)
# ---------------------------------------------------------------------------

def pearson_correlation(x: np.ndarray, y: np.ndarray) -> dict:
    """
    Compute Pearson's r between x and y.

    Returns dict with r, p_value, n.
    """
    mask = ~(np.isnan(x) | np.isnan(y))
    xv, yv = x[mask], y[mask]
    if len(xv) < 3:
        return {"r": np.nan, "p_value": np.nan, "n": 0}
    r, p = scipy_stats.pearsonr(xv, yv)
    return {"r": float(r), "p_value": float(p), "n": int(len(xv))}


# ---------------------------------------------------------------------------
# Spearman's ρ (Eq. 16)
# ---------------------------------------------------------------------------

def spearman_correlation(x: np.ndarray, y: np.ndarray) -> dict:
    """
    Compute Spearman's ρ between x and y.

    Returns dict with rho, p_value, n.
    """
    mask = ~(np.isnan(x) | np.isnan(y))
    xv, yv = x[mask], y[mask]
    if len(xv) < 3:
        return {"rho": np.nan, "p_value": np.nan, "n": 0}
    rho, p = scipy_stats.spearmanr(xv, yv)
    return {"rho": float(rho), "p_value": float(p), "n": int(len(xv))}


# ---------------------------------------------------------------------------
# Autocorrelation function — ACF (Eq. 17)
# ---------------------------------------------------------------------------

def autocorrelation(series: np.ndarray, max_lag: int = 24) -> pd.DataFrame:
    """
    Compute the sample Autocorrelation Function (ACF) up to *max_lag*.

    ACF(k) = Σ_{t=1}^{n-k} (Y_t - Ȳ)(Y_{t+k} - Ȳ) / Σ_{t=1}^{n} (Y_t - Ȳ)²

    Returns
    -------
    DataFrame with columns [lag, acf, conf_lower, conf_upper] (95% CI under H0)
    """
    y    = series.copy()
    y    = y[~np.isnan(y)]
    n    = len(y)
    ybar = y.mean()
    denom = np.sum((y - ybar) ** 2)

    lags, acf_vals = [], []
    for k in range(0, min(max_lag + 1, n - 1)):
        if denom == 0:
            acf_vals.append(np.nan)
        else:
            num = np.sum((y[:n-k] - ybar) * (y[k:] - ybar))
            acf_vals.append(float(num / denom))
        lags.append(k)

    # 95% confidence interval (Bartlett)
    ci = 1.96 / np.sqrt(n)
    df = pd.DataFrame({
        "lag"        : lags,
        "acf"        : acf_vals,
        "conf_lower" : -ci,
        "conf_upper" : ci,
    })
    return df


# ---------------------------------------------------------------------------
# Comprehensive correlation table
# ---------------------------------------------------------------------------

def correlation_matrix(
    vi_csv: str,
    climate_tmp_csv: str,
    climate_pre_csv: str,
    grace_csv: str,
    output_dir: str,
) -> pd.DataFrame:
    """
    Build a comprehensive Pearson + Spearman correlation matrix between
    vegetation indices and climate / groundwater variables.

    Saves results to CSV and returns the DataFrame.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Load all time series
    vi   = pd.read_csv(vi_csv, parse_dates=["date"] if "date" in
                       pd.read_csv(vi_csv, nrows=0).columns else [])
    if "date" in vi.columns:
        vi = vi.set_index("date").sort_index()

    records = []

    # Climate variables
    climate_files = {}
    if os.path.exists(climate_tmp_csv):
        climate_files["temperature_C"] = (climate_tmp_csv, "mean")
    if os.path.exists(climate_pre_csv):
        climate_files["rainfall_mm"]   = (climate_pre_csv, "mean")
    if os.path.exists(grace_csv):
        climate_files["groundwater_mm"]= (grace_csv, "mean_tws_mm")

    vi_metrics = [c for c in vi.columns if c.endswith("_mean")]

    for vi_col in vi_metrics:
        if vi_col not in vi.columns:
            continue
        vi_series = vi[vi_col].dropna()

        for clim_name, (csv_path, val_col) in climate_files.items():
            try:
                clim_df  = pd.read_csv(csv_path, parse_dates=["date"])
                clim_df  = clim_df.set_index("date").sort_index()
                if val_col not in clim_df.columns:
                    log.warning("Column '%s' not in %s — skipping.", val_col, csv_path)
                    continue
                clim_series = clim_df[val_col].dropna()

                # Align
                aligned = pd.concat([vi_series, clim_series], axis=1, join="inner").dropna()
                if len(aligned) < 5:
                    log.warning("Insufficient overlap for %s vs %s (%d points).",
                                vi_col, clim_name, len(aligned))
                    continue

                x = aligned.iloc[:, 0].values
                y = aligned.iloc[:, 1].values

                pear = pearson_correlation(x, y)
                spea = spearman_correlation(x, y)

                records.append({
                    "vi_variable"    : vi_col,
                    "climate_variable": clim_name,
                    "pearson_r"      : pear["r"],
                    "pearson_p"      : pear["p_value"],
                    "spearman_rho"   : spea["rho"],
                    "spearman_p"     : spea["p_value"],
                    "n"              : pear["n"],
                    "significant_5pct": pear["p_value"] < ANALYSIS["alpha"],
                })
                log.info(
                    "%-20s vs %-20s : r=%.3f (p=%.4f), ρ=%.3f (p=%.4f), n=%d",
                    vi_col, clim_name,
                    pear["r"], pear["p_value"],
                    spea["rho"], spea["p_value"],
                    pear["n"],
                )
            except Exception as exc:
                log.error("Error processing %s vs %s: %s", vi_col, clim_name, exc)

    df      = pd.DataFrame(records)
    csv_out = os.path.join(output_dir, "correlation_matrix.csv")
    df.to_csv(csv_out, index=False)
    log.info("Correlation matrix saved → %s", csv_out)
    return df


# ---------------------------------------------------------------------------
# Full trend analysis table
# ---------------------------------------------------------------------------

def all_trends(
    vi_csv: str,
    output_dir: str,
) -> pd.DataFrame:
    """
    Fit linear trends + STL decomposition for all VI metrics.

    Saves trend summary to CSV.
    """
    os.makedirs(output_dir, exist_ok=True)
    vi = pd.read_csv(vi_csv)
    if "date" in vi.columns:
        vi["date"] = pd.to_datetime(vi["date"])
        vi = vi.set_index("date").sort_index()

    vi_cols   = [c for c in vi.columns if c.endswith("_mean")]
    trend_rows = []
    acf_dfs    = {}

    for col in vi_cols:
        series = vi[col].dropna()
        if len(series) < 6:
            continue

        t_result = linear_trend(series)
        t_result["variable"] = col
        trend_rows.append(t_result)

        # STL decomposition → save
        stl_df = stl_decompose(series, period=12)
        stl_df.to_csv(os.path.join(output_dir, f"stl_{col}.csv"))

        # ACF
        acf_df = autocorrelation(series.values, max_lag=24)
        acf_df["variable"] = col
        acf_dfs[col]       = acf_df

    trend_df = pd.DataFrame(trend_rows)
    trend_df.to_csv(os.path.join(output_dir, "vi_trends.csv"), index=False)
    log.info("VI trend summary:\n%s", trend_df[["variable","slope","r2","p_value"]].to_string())

    # Save all ACF
    if acf_dfs:
        acf_all = pd.concat(acf_dfs.values(), ignore_index=True)
        acf_all.to_csv(os.path.join(output_dir, "vi_acf.csv"), index=False)

    return trend_df


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Trend and correlation analysis for VI and climate variables."
    )
    parser.add_argument("--indices",    default=RES_INDICES)
    parser.add_argument("--climate",    default=PROC_CRUTS)
    parser.add_argument("--grace",      default=os.path.join(PROC_GRACE,
                                            "grace_tws_alqassim_timeseries.csv"))
    parser.add_argument("--output",     default=RES_ANALYSIS)
    args = parser.parse_args()

    vi_csv   = os.path.join(args.indices,  "vegetation_indices_timeseries.csv")
    tmp_csv  = os.path.join(args.climate,  "cruts_tmp_alqassim_timeseries.csv")
    pre_csv  = os.path.join(args.climate,  "cruts_pre_alqassim_timeseries.csv")

    all_trends(vi_csv, args.output)
    correlation_matrix(vi_csv, tmp_csv, pre_csv, args.grace, args.output)


if __name__ == "__main__":
    main()
