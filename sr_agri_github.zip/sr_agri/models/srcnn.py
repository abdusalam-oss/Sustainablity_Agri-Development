"""
models/srcnn.py
================
Super-Resolution Convolutional Neural Network (SRCNN).

Architecture (Dong et al., 2014 — adapted for 6-band multispectral input)
--------------------------------------------------------------------------
Layer 1  — Patch extraction:      Conv(9×9, 64 filters)  + ReLU
Layer 2  — Non-linear mapping:    Conv(1×1, 32 filters)  + ReLU
Layer 3  — Reconstruction:        Conv(5×5,  C filters)  (linear, no activation)

The model learns to map a bicubic-interpolated LR image directly to HR.

Mathematical formulation (Equation 2 in paper)
----------------------------------------------
    F(Y) = max(0, W3 * max(0, W2 * max(0, W1 * Y + b1) + b2) + b3)

Usage
-----
    # Train
    python models/srcnn.py \
        --data   data/processed/landsat \
        --epochs 200 \
        --batch  16 \
        --output results/srcnn

    # Evaluate only
    python models/srcnn.py \
        --data   data/processed/landsat \
        --output results/srcnn \
        --eval_only
"""

import os
import argparse
import logging
import json

import numpy as np

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import SRCNN as CFG, PATCH, RES_SRCNN, PROC_LANDSAT, CHECKPOINTS_DIR
from models.bicubic_interpolation import bicubic_upsample, compute_metrics

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Model definition
# ---------------------------------------------------------------------------

def build_srcnn(input_shape: tuple, n_channels: int = 6) -> "tf.keras.Model":
    """
    Build and return the SRCNN model.

    Parameters
    ----------
    input_shape : (H, W, C) — shape of the bicubic-interpolated LR input
    n_channels  : number of output channels (= number of Landsat bands)

    Returns
    -------
    tf.keras.Model
    """
    import tensorflow as tf
    from tensorflow.keras import layers, Model

    inputs = tf.keras.Input(shape=input_shape, name="lr_bicubic_input")

    # Layer 1: Patch extraction
    x = layers.Conv2D(
        filters=CFG["filters"][0],
        kernel_size=CFG["kernels"][0],
        padding="same",
        activation="relu",
        kernel_initializer="he_normal",
        name="patch_extraction",
    )(inputs)

    # Layer 2: Non-linear mapping
    x = layers.Conv2D(
        filters=CFG["filters"][1],
        kernel_size=CFG["kernels"][1],
        padding="same",
        activation="relu",
        kernel_initializer="he_normal",
        name="nonlinear_mapping",
    )(x)

    # Layer 3: Reconstruction (linear output, no activation)
    outputs = layers.Conv2D(
        filters=n_channels,
        kernel_size=CFG["kernels"][2],
        padding="same",
        activation="linear",
        kernel_initializer="glorot_uniform",
        name="reconstruction",
    )(x)

    model = Model(inputs=inputs, outputs=outputs, name="SRCNN")
    return model


# ---------------------------------------------------------------------------
# Data loader
# ---------------------------------------------------------------------------

def load_patches(data_dir: str, split: str = "train") -> tuple[np.ndarray, np.ndarray]:
    """
    Load LR / HR patch pairs from a pre-extracted .npz file.
    LR patches are bicubic-upsampled to HR size before being fed to the network.
    """
    npz_path = os.path.join(data_dir, f"patches_{split}.npz")
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"Patch file not found: {npz_path}")

    data = np.load(npz_path)
    lr   = data["lr"]    # (N, lr_size, lr_size, C)
    hr   = data["hr"]    # (N, hr_size, hr_size, C)

    # Bicubic upsample LR → HR size (SRCNN takes interpolated input)
    log.info("Bicubic-upsampling %d '%s' LR patches to HR size …", len(lr), split)
    lr_up = np.stack([bicubic_upsample(p, scale=PATCH["scale"]) for p in lr], axis=0)
    return lr_up.astype(np.float32), hr.astype(np.float32)


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

def train(
    data_dir: str,
    output_dir: str,
    epochs: int,
    batch_size: int,
    lr: float,
) -> dict:
    """
    Train SRCNN and return best validation metrics.
    """
    import tensorflow as tf

    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(CHECKPOINTS_DIR, exist_ok=True)

    # Load data
    log.info("Loading training patches …")
    x_train, y_train = load_patches(data_dir, "train")
    x_val,   y_val   = load_patches(data_dir, "val")

    n_channels   = x_train.shape[-1]
    input_shape  = x_train.shape[1:]   # (hr_size, hr_size, C)

    log.info("Train: %d patches | Val: %d patches | Input shape: %s",
             len(x_train), len(x_val), input_shape)

    # Build model
    model = build_srcnn(input_shape=input_shape, n_channels=n_channels)
    model.summary(print_fn=log.info)

    optimizer = tf.keras.optimizers.Adam(learning_rate=lr)
    model.compile(optimizer=optimizer, loss=CFG["loss"])

    # Callbacks
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(
            filepath  = CFG["checkpoint"],
            monitor   = "val_loss",
            save_best_only=True,
            verbose   = 1,
        ),
        tf.keras.callbacks.EarlyStopping(
            monitor   = "val_loss",
            patience  = 20,
            restore_best_weights=True,
            verbose   = 1,
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor   = "val_loss",
            factor    = 0.5,
            patience  = 10,
            min_lr    = 1e-7,
            verbose   = 1,
        ),
        tf.keras.callbacks.CSVLogger(
            os.path.join(output_dir, "srcnn_training_log.csv"),
        ),
    ]

    log.info("Starting SRCNN training (%d epochs, batch %d) …", epochs, batch_size)
    history = model.fit(
        x_train, y_train,
        validation_data=(x_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=2,
    )

    # Save final model
    final_path = os.path.join(output_dir, "srcnn_final.h5")
    model.save(final_path)
    log.info("Final SRCNN model saved → %s", final_path)

    best_val_loss = float(min(history.history["val_loss"]))
    return {"best_val_loss": best_val_loss}


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------

def evaluate(data_dir: str, output_dir: str, model_path: str = None) -> dict:
    """
    Evaluate SRCNN on the test set and compute RMSE, PSNR, SSIM.
    """
    import tensorflow as tf
    import pandas as pd

    os.makedirs(output_dir, exist_ok=True)

    if model_path is None:
        # Try best checkpoint, then final model
        for candidate in [CFG["checkpoint"],
                          os.path.join(output_dir, "srcnn_final.h5")]:
            if os.path.exists(candidate):
                model_path = candidate
                break
    if model_path is None or not os.path.exists(model_path):
        log.error("No trained SRCNN model found. Run training first.")
        return {}

    log.info("Loading model from %s …", model_path)
    model = tf.keras.models.load_model(model_path)

    log.info("Loading test patches …")
    x_test, y_test = load_patches(data_dir, "test")

    log.info("Running inference on %d test patches …", len(x_test))
    preds   = model.predict(x_test, batch_size=16, verbose=0)
    preds   = np.clip(preds, 0.0, 1.0)

    records = []
    for i in range(len(preds)):
        m = compute_metrics(preds[i], y_test[i])
        records.append(m)

    df   = pd.DataFrame(records)
    mean = {k: float(df[k].mean()) for k in ["rmse", "psnr", "ssim"]}
    df.to_csv(os.path.join(output_dir, "srcnn_metrics_per_patch.csv"), index=False)

    # Save summary
    with open(os.path.join(output_dir, "srcnn_summary.json"), "w") as f:
        json.dump(mean, f, indent=2)

    log.info(
        "SRCNN — RMSE: %.4f | PSNR: %.2f dB | SSIM: %.4f",
        mean["rmse"], mean["psnr"], mean["ssim"],
    )
    return mean


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Train and evaluate SRCNN for super-resolution.")
    parser.add_argument("--data",      default=PROC_LANDSAT)
    parser.add_argument("--output",    default=RES_SRCNN)
    parser.add_argument("--epochs",    type=int,   default=CFG["epochs"])
    parser.add_argument("--batch",     type=int,   default=CFG["batch_size"])
    parser.add_argument("--lr",        type=float, default=CFG["lr"])
    parser.add_argument("--eval_only", action="store_true")
    parser.add_argument("--model",     default=None, help="Path to saved model for evaluation.")
    args = parser.parse_args()

    if not args.eval_only:
        train(args.data, args.output, args.epochs, args.batch, args.lr)

    evaluate(args.data, args.output, model_path=args.model)


if __name__ == "__main__":
    main()
