"""
models/bicubic_interpolation.py
================================
Bicubic interpolation baseline for image super-resolution.

Implements the bicubic upscaling method described in the paper (Equation 1)
and evaluates it on the Landsat patch test set using RMSE, PSNR, and SSIM.

Mathematical formulation (Equation 1 in paper)
----------------------------------------------
    I_high(x, y) = Σ_{i=-1}^{2} Σ_{j=-1}^{2} I_low(x+i, y+j) × w(i, j)

where w(i, j) are bicubic interpolation weights derived from the
cubic Hermite kernel with a = -0.5.

Usage
-----
    python models/bicubic_interpolation.py \
        --data   data/processed/landsat \
        --output results/bicubic
"""

import os
import argparse
import logging

import numpy as np
from skimage.transform import resize
from skimage.metrics import structural_similarity as ssim_fn
from skimage.metrics import peak_signal_noise_ratio as psnr_fn
import rasterio
from glob import glob
import tifffile

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import PATCH, RES_BICUBIC, PROC_LANDSAT

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core bicubic upscale
# ---------------------------------------------------------------------------

def bicubic_upsample(lr_image: np.ndarray, scale: int = 4) -> np.ndarray:
    """
    Upsample *lr_image* by *scale* using bicubic interpolation.

    Parameters
    ----------
    lr_image : np.ndarray, shape (H, W, C) or (H, W), float32 in [0, 1]
    scale    : integer upscaling factor

    Returns
    -------
    np.ndarray, shape (H*scale, W*scale, C) or (H*scale, W*scale), float32
    """
    if lr_image.ndim == 2:
        h, w = lr_image.shape
        return resize(lr_image, (h * scale, w * scale),
                      order=3, anti_aliasing=False,
                      preserve_range=True).astype(np.float32)
    h, w, c = lr_image.shape
    return resize(lr_image, (h * scale, w * scale, c),
                  order=3, anti_aliasing=False,
                  preserve_range=True).astype(np.float32)


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def compute_metrics(
    pred: np.ndarray,
    target: np.ndarray,
    data_range: float = 1.0,
) -> dict:
    """
    Compute RMSE, PSNR, and SSIM between *pred* and *target*.

    Parameters
    ----------
    pred, target : np.ndarray, shape (H, W, C) or (H, W), float32 in [0, 1]
    data_range   : maximum value of the data (1.0 for normalized images)

    Returns
    -------
    dict with keys 'rmse', 'psnr', 'ssim'
    """
    rmse = float(np.sqrt(np.mean((pred - target) ** 2)))

    # Per-channel PSNR then average
    if pred.ndim == 3:
        psnr_vals = [psnr_fn(target[:, :, c], pred[:, :, c], data_range=data_range)
                     for c in range(pred.shape[2])]
        psnr = float(np.mean(psnr_vals))
        # SSIM on first channel (NIR / Red)
        ssim_val = float(ssim_fn(
            target[:, :, 0], pred[:, :, 0],
            data_range=data_range,
        ))
    else:
        psnr    = float(psnr_fn(target, pred, data_range=data_range))
        ssim_val = float(ssim_fn(target, pred, data_range=data_range))

    return {"rmse": rmse, "psnr": psnr, "ssim": ssim_val}


# ---------------------------------------------------------------------------
# Evaluation on test set
# ---------------------------------------------------------------------------

def evaluate_on_test_set(data_dir: str, output_dir: str, scale: int = 4) -> dict:
    """
    Run bicubic upsampling on the Landsat patch test set and report metrics.

    Parameters
    ----------
    data_dir   : directory containing 'patches_test.npz'
    output_dir : directory to save per-patch SR images and metric CSV

    Returns
    -------
    dict with mean RMSE, PSNR, SSIM across all test patches
    """
    import pandas as pd

    test_npz = os.path.join(data_dir, "patches_test.npz")
    if not os.path.exists(test_npz):
        log.error("Test patch file not found: %s", test_npz)
        return {}

    os.makedirs(output_dir, exist_ok=True)
    log.info("Loading test patches from %s …", test_npz)
    data    = np.load(test_npz)
    lr_patches = data["lr"]    # (N, lr_size, lr_size, C)
    hr_patches = data["hr"]    # (N, hr_size, hr_size, C)

    log.info("Evaluating bicubic baseline on %d test patches …", len(lr_patches))

    records = []
    for i, (lr, hr) in enumerate(zip(lr_patches, hr_patches)):
        sr = bicubic_upsample(lr, scale=scale)
        # Clamp
        sr = np.clip(sr, 0.0, 1.0)
        m  = compute_metrics(sr, hr)
        records.append(m)

        # Save every 100th patch as a preview TIFF
        if i % 100 == 0:
            preview_path = os.path.join(output_dir, f"bicubic_patch_{i:05d}.tif")
            # Save RGB (bands 2,1,0 = R,G,B for display)
            tifffile.imwrite(preview_path, (sr[:, :, :3] * 255).astype(np.uint8))

    df   = pd.DataFrame(records)
    mean = {k: float(df[k].mean()) for k in ["rmse", "psnr", "ssim"]}
    df.to_csv(os.path.join(output_dir, "bicubic_metrics_per_patch.csv"), index=False)

    log.info(
        "Bicubic Interpolation — RMSE: %.4f | PSNR: %.2f dB | SSIM: %.4f",
        mean["rmse"], mean["psnr"], mean["ssim"],
    )
    return mean


def upsample_scene(
    lr_scene_path: str,
    output_path: str,
    scale: int = 4,
) -> None:
    """
    Apply bicubic upsampling to a full Landsat scene GeoTIFF.

    Parameters
    ----------
    lr_scene_path : path to LR input GeoTIFF
    output_path   : path for SR output GeoTIFF
    scale         : upscaling factor
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with rasterio.open(lr_scene_path) as src:
        meta = src.meta.copy()
        data = src.read().astype(np.float32)   # (C, H, W)
        C, H, W = data.shape

        # Reproject metadata for the new resolution
        from rasterio.transform import Affine
        old_t = src.transform
        new_res_x = old_t.a / scale
        new_res_y = old_t.e / scale  # negative for N-up rasters
        new_transform = Affine(new_res_x, 0.0, old_t.c,
                               0.0, new_res_y, old_t.f)

        meta.update({
            "width"    : W * scale,
            "height"   : H * scale,
            "transform": new_transform,
        })

    sr_bands = []
    for c in range(C):
        band = data[c]
        sr   = bicubic_upsample(band, scale=scale)
        sr_bands.append(sr)

    sr_array = np.stack(sr_bands, axis=0)
    with rasterio.open(output_path, "w", **meta) as dst:
        dst.write(sr_array)

    log.info("Bicubic SR scene saved → %s", output_path)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate bicubic interpolation baseline on Landsat patch test set."
    )
    parser.add_argument("--data",   default=PROC_LANDSAT,
                        help="Directory containing patches_test.npz.")
    parser.add_argument("--output", default=RES_BICUBIC,
                        help="Directory for output metrics and previews.")
    parser.add_argument("--scale",  type=int, default=PATCH["scale"],
                        help="Upscaling factor (default: 4).")
    parser.add_argument("--scene",  default=None,
                        help="Optional: path to a single LR GeoTIFF scene to upsample.")
    args = parser.parse_args()

    if args.scene:
        out_path = os.path.join(args.output,
                                os.path.basename(args.scene).replace(".tif", "_bicubic_sr.tif"))
        upsample_scene(args.scene, out_path, scale=args.scale)
    else:
        evaluate_on_test_set(args.data, args.output, scale=args.scale)


if __name__ == "__main__":
    main()
