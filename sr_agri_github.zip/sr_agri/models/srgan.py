"""
models/srgan.py
================
Super-Resolution Generative Adversarial Network (SRGAN).

Architecture
------------
Generator  : Modified ResNet with 16 residual blocks, sub-pixel convolution
             for ×4 upscaling (Ledig et al., 2017; adapted for multispectral).
Discriminator: VGG-style classifier that distinguishes real HR from generated SR.

Loss function (Equation 3 in paper)
------------------------------------
    L_SRGAN = E[log D(I_HR)] + E[log(1 - D(G(I_LR)))] + λ · L_content

where L_content is a perceptual loss computed on VGG-19 feature maps (block5_conv4)
and λ = 1e-3 balances adversarial and content terms.

Training strategy
-----------------
1. Pre-train generator with pixel-wise MSE loss for CFG["pretrain_epochs"] epochs
   (warm-up before adversarial training begins).
2. Adversarial training for CFG["epochs"] epochs using the combined loss above.

Usage
-----
    python models/srgan.py \
        --data   data/processed/landsat \
        --epochs 200 \
        --batch  16 \
        --output results/srgan

    python models/srgan.py \
        --data   data/processed/landsat \
        --output results/srgan \
        --eval_only
"""

import os
import argparse
import logging
import json

import numpy as np

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import SRGAN as CFG, PATCH, RES_SRGAN, PROC_LANDSAT, CHECKPOINTS_DIR
from models.bicubic_interpolation import compute_metrics

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Generator: ResNet + sub-pixel convolution
# ---------------------------------------------------------------------------

def _residual_block(x, filters: int = 64, name_prefix: str = "res"):
    """Single residual block: Conv → BN → PReLU → Conv → BN → add."""
    import tensorflow as tf
    from tensorflow.keras import layers

    shortcut = x
    x = layers.Conv2D(filters, 3, padding="same",
                      kernel_initializer="he_normal",
                      name=f"{name_prefix}_conv1")(x)
    x = layers.BatchNormalization(momentum=0.8, name=f"{name_prefix}_bn1")(x)
    x = layers.PReLU(shared_axes=[1, 2], name=f"{name_prefix}_prelu")(x)
    x = layers.Conv2D(filters, 3, padding="same",
                      kernel_initializer="he_normal",
                      name=f"{name_prefix}_conv2")(x)
    x = layers.BatchNormalization(momentum=0.8, name=f"{name_prefix}_bn2")(x)
    x = layers.Add(name=f"{name_prefix}_add")([shortcut, x])
    return x


def _upsampling_block(x, filters: int = 256, name_prefix: str = "up"):
    """Sub-pixel convolution upsampling block (×2)."""
    import tensorflow as tf
    from tensorflow.keras import layers

    x = layers.Conv2D(filters, 3, padding="same",
                      kernel_initializer="he_normal",
                      name=f"{name_prefix}_conv")(x)
    x = tf.nn.depth_to_space(x, 2)       # sub-pixel shuffle (×2)
    x = layers.PReLU(shared_axes=[1, 2],
                     name=f"{name_prefix}_prelu")(x)
    return x


def build_generator(
    lr_shape: tuple,
    n_channels: int = 6,
    n_residual_blocks: int = 16,
) -> "tf.keras.Model":
    """
    Build the SRGAN generator.

    Parameters
    ----------
    lr_shape          : (H, W, C) — LR input shape
    n_channels        : number of output channels
    n_residual_blocks : number of residual blocks (default 16)

    Returns
    -------
    tf.keras.Model
    """
    import tensorflow as tf
    from tensorflow.keras import layers, Model

    inputs = tf.keras.Input(shape=lr_shape, name="lr_input")

    # Initial convolution
    x = layers.Conv2D(64, 9, padding="same",
                      kernel_initializer="he_normal", name="initial_conv")(inputs)
    x = layers.PReLU(shared_axes=[1, 2], name="initial_prelu")(x)
    skip = x

    # Residual blocks
    for i in range(n_residual_blocks):
        x = _residual_block(x, filters=64, name_prefix=f"res_{i+1}")

    # Post-residual convolution + BN
    x = layers.Conv2D(64, 3, padding="same",
                      kernel_initializer="he_normal", name="post_res_conv")(x)
    x = layers.BatchNormalization(momentum=0.8, name="post_res_bn")(x)
    x = layers.Add(name="skip_add")([skip, x])

    # Upsampling blocks (×2 each = ×4 total for scale=4)
    x = _upsampling_block(x, filters=256, name_prefix="up1")
    x = _upsampling_block(x, filters=256, name_prefix="up2")

    # Output convolution
    outputs = layers.Conv2D(
        n_channels, 9, padding="same",
        activation="sigmoid",
        kernel_initializer="glorot_uniform",
        name="output_conv",
    )(x)

    return Model(inputs=inputs, outputs=outputs, name="SRGAN_Generator")


# ---------------------------------------------------------------------------
# Discriminator: VGG-style
# ---------------------------------------------------------------------------

def build_discriminator(hr_shape: tuple) -> "tf.keras.Model":
    """
    Build the SRGAN discriminator.

    Parameters
    ----------
    hr_shape : (H, W, C) — HR patch shape

    Returns
    -------
    tf.keras.Model
    """
    import tensorflow as tf
    from tensorflow.keras import layers, Model

    def _disc_block(x, filters, stride, name):
        x = layers.Conv2D(filters, 3, strides=stride, padding="same",
                          kernel_initializer="he_normal", use_bias=False,
                          name=f"{name}_conv")(x)
        x = layers.BatchNormalization(momentum=0.8, name=f"{name}_bn")(x)
        x = layers.LeakyReLU(0.2, name=f"{name}_lrelu")(x)
        return x

    inputs = tf.keras.Input(shape=hr_shape, name="hr_input")

    # Initial block (no BN on first layer)
    x = layers.Conv2D(64, 3, padding="same",
                      kernel_initializer="he_normal", name="d_conv0")(inputs)
    x = layers.LeakyReLU(0.2, name="d_lrelu0")(x)

    cfg = [(64, 2), (128, 1), (128, 2), (256, 1), (256, 2), (512, 1), (512, 2)]
    for idx, (f, s) in enumerate(cfg):
        x = _disc_block(x, f, s, name=f"d_block{idx+1}")

    x = layers.GlobalAveragePooling2D(name="d_gap")(x)
    x = layers.Dense(1024, kernel_initializer="he_normal", name="d_dense")(x)
    x = layers.LeakyReLU(0.2, name="d_dense_lrelu")(x)
    outputs = layers.Dense(1, activation="sigmoid",
                           kernel_initializer="glorot_uniform",
                           name="d_output")(x)

    return Model(inputs=inputs, outputs=outputs, name="SRGAN_Discriminator")


# ---------------------------------------------------------------------------
# VGG perceptual feature extractor
# ---------------------------------------------------------------------------

def build_vgg_feature_extractor(input_shape: tuple) -> "tf.keras.Model":
    """
    Build a VGG-19 feature extractor up to block5_conv4.

    The model maps a 3-channel RGB image to intermediate feature maps
    used to compute the content / perceptual loss.
    """
    import tensorflow as tf
    from tensorflow.keras.applications import VGG19
    from tensorflow.keras import Model

    # VGG expects 3-channel input; we use the first 3 bands (Blue, Green, Red)
    vgg = VGG19(include_top=False, weights="imagenet",
                input_shape=(input_shape[0], input_shape[1], 3))
    vgg.trainable = False
    feature_layer = vgg.get_layer(CFG["vgg_layer"]).output
    return Model(inputs=vgg.input, outputs=feature_layer, name="VGG_Features")


# ---------------------------------------------------------------------------
# Losses
# ---------------------------------------------------------------------------

def pixel_loss(y_true, y_pred):
    """Mean squared error on pixel values."""
    import tensorflow as tf
    return tf.reduce_mean(tf.square(y_true - y_pred))


def perceptual_loss(vgg, y_true_rgb, y_pred_rgb):
    """
    VGG-based perceptual (content) loss — MSE on feature maps.
    Operates on the first 3 channels (B, G, R → rescaled to [0, 255] for VGG).
    """
    import tensorflow as tf
    scale = 255.0
    feat_true = vgg(y_true_rgb * scale, training=False)
    feat_pred = vgg(y_pred_rgb * scale, training=False)
    return tf.reduce_mean(tf.square(feat_true - feat_pred))


def adversarial_loss_gen(disc_pred_fake):
    """Generator adversarial loss: -log D(G(LR))."""
    import tensorflow as tf
    return tf.reduce_mean(-tf.math.log(disc_pred_fake + 1e-8))


def adversarial_loss_disc(disc_pred_real, disc_pred_fake):
    """
    Discriminator loss: -[log D(HR) + log(1 - D(G(LR)))].
    """
    import tensorflow as tf
    real_loss = tf.reduce_mean(-tf.math.log(disc_pred_real + 1e-8))
    fake_loss = tf.reduce_mean(-tf.math.log(1.0 - disc_pred_fake + 1e-8))
    return real_loss + fake_loss


# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

def _load_patches(data_dir: str, split: str) -> tuple[np.ndarray, np.ndarray]:
    npz_path = os.path.join(data_dir, f"patches_{split}.npz")
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"Patch file not found: {npz_path}")
    data = np.load(npz_path)
    return data["lr"].astype(np.float32), data["hr"].astype(np.float32)


def train(
    data_dir: str,
    output_dir: str,
    epochs: int,
    batch_size: int,
    lr_gen: float,
    lr_disc: float,
) -> None:
    import tensorflow as tf

    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(CHECKPOINTS_DIR, exist_ok=True)

    log.info("Loading patches …")
    lr_train, hr_train = _load_patches(data_dir, "train")
    lr_val,   hr_val   = _load_patches(data_dir, "val")

    n_channels  = lr_train.shape[-1]
    lr_shape    = lr_train.shape[1:]
    hr_shape    = hr_train.shape[1:]

    log.info("LR shape: %s | HR shape: %s | Channels: %d", lr_shape, hr_shape, n_channels)
    log.info("Train: %d patches | Val: %d patches", len(lr_train), len(lr_val))

    # Build models
    generator     = build_generator(lr_shape, n_channels=n_channels)
    discriminator = build_discriminator(hr_shape)
    vgg           = build_vgg_feature_extractor(hr_shape)

    generator.summary(print_fn=log.info)
    discriminator.summary(print_fn=log.info)

    gen_opt  = tf.keras.optimizers.Adam(learning_rate=lr_gen,  beta_1=0.9)
    disc_opt = tf.keras.optimizers.Adam(learning_rate=lr_disc, beta_1=0.9)

    # ----------------------------------------------------------------
    # Phase 1: Pre-train generator with pixel MSE loss
    # ----------------------------------------------------------------
    log.info("=== Phase 1: Generator pre-training (%d epochs) ===",
             CFG["pretrain_epochs"])
    generator.compile(optimizer=tf.keras.optimizers.Adam(lr_gen), loss="mse")
    generator.fit(
        lr_train, hr_train,
        validation_data=(lr_val, hr_val),
        epochs=CFG["pretrain_epochs"],
        batch_size=batch_size,
        verbose=2,
        callbacks=[
            tf.keras.callbacks.CSVLogger(
                os.path.join(output_dir, "srgan_pretrain_log.csv")),
        ],
    )
    log.info("Pre-training complete.")

    # ----------------------------------------------------------------
    # Phase 2: Adversarial training
    # ----------------------------------------------------------------
    log.info("=== Phase 2: Adversarial training (%d epochs) ===", epochs)

    n_batches  = len(lr_train) // batch_size
    best_val_psnr = 0.0
    history = {"gen_total": [], "gen_pixel": [], "gen_perc": [],
               "gen_adv": [], "disc": [], "val_psnr": [], "val_ssim": []}

    @tf.function
    def train_step(lr_batch, hr_batch):
        with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
            # Forward pass
            sr_batch = generator(lr_batch, training=True)

            # Discriminator predictions
            disc_real = discriminator(hr_batch,  training=True)
            disc_fake = discriminator(sr_batch,  training=True)

            # Generator losses
            l_pixel = pixel_loss(hr_batch, sr_batch)
            # Perceptual loss on first 3 bands (B, G, R)
            l_perc  = perceptual_loss(vgg, hr_batch[:, :, :, :3], sr_batch[:, :, :, :3])
            l_adv   = adversarial_loss_gen(disc_fake)
            l_gen   = l_pixel + CFG["lambda_content"] * l_adv + 1e-6 * l_perc

            # Discriminator loss
            l_disc  = adversarial_loss_disc(disc_real, disc_fake)

        gen_grads  = gen_tape.gradient(l_gen, generator.trainable_variables)
        disc_grads = disc_tape.gradient(l_disc, discriminator.trainable_variables)

        gen_opt.apply_gradients(zip(gen_grads,  generator.trainable_variables))
        disc_opt.apply_gradients(zip(disc_grads, discriminator.trainable_variables))

        return l_gen, l_pixel, l_perc, l_adv, l_disc

    csv_log = open(os.path.join(output_dir, "srgan_training_log.csv"), "w")
    csv_log.write("epoch,gen_total,gen_pixel,gen_perc,gen_adv,disc,val_psnr,val_ssim\n")

    for epoch in range(1, epochs + 1):
        epoch_gen, epoch_pix, epoch_per, epoch_adv, epoch_disc = [], [], [], [], []
        # Shuffle
        perm     = np.random.permutation(len(lr_train))
        lr_shuf  = lr_train[perm]
        hr_shuf  = hr_train[perm]

        for b in range(n_batches):
            lr_b = tf.constant(lr_shuf[b*batch_size:(b+1)*batch_size])
            hr_b = tf.constant(hr_shuf[b*batch_size:(b+1)*batch_size])
            l_g, l_p, l_c, l_a, l_d = train_step(lr_b, hr_b)
            epoch_gen.append(float(l_g)); epoch_pix.append(float(l_p))
            epoch_per.append(float(l_c)); epoch_adv.append(float(l_a))
            epoch_disc.append(float(l_d))

        # Validation
        val_preds  = generator.predict(lr_val, batch_size=batch_size, verbose=0)
        val_preds  = np.clip(val_preds, 0.0, 1.0)
        val_metrics = [compute_metrics(val_preds[i], hr_val[i]) for i in range(len(hr_val))]
        val_psnr = float(np.mean([m["psnr"] for m in val_metrics]))
        val_ssim = float(np.mean([m["ssim"] for m in val_metrics]))

        mean_gen  = float(np.mean(epoch_gen))
        mean_pix  = float(np.mean(epoch_pix))
        mean_per  = float(np.mean(epoch_per))
        mean_adv  = float(np.mean(epoch_adv))
        mean_disc = float(np.mean(epoch_disc))

        log.info(
            "Epoch %3d/%d | G_total=%.4f | G_pix=%.4f | G_perc=%.6f | "
            "G_adv=%.4f | D=%.4f | Val_PSNR=%.2f dB | Val_SSIM=%.4f",
            epoch, epochs, mean_gen, mean_pix, mean_per,
            mean_adv, mean_disc, val_psnr, val_ssim,
        )
        csv_log.write(f"{epoch},{mean_gen:.6f},{mean_pix:.6f},{mean_per:.6f},"
                      f"{mean_adv:.6f},{mean_disc:.6f},{val_psnr:.4f},{val_ssim:.4f}\n")
        csv_log.flush()

        # Save best generator
        if val_psnr > best_val_psnr:
            best_val_psnr = val_psnr
            generator.save(CFG["checkpoint_gen"])
            discriminator.save(CFG["checkpoint_disc"])
            log.info("  → New best model saved (PSNR=%.2f dB).", val_psnr)

        # Periodic checkpoint
        if epoch % CFG["save_interval"] == 0:
            ckpt = os.path.join(output_dir, f"srgan_gen_epoch{epoch:04d}.h5")
            generator.save(ckpt)

    csv_log.close()
    generator.save(os.path.join(output_dir, "srgan_gen_final.h5"))
    log.info("Training complete. Best val PSNR: %.2f dB", best_val_psnr)


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------

def evaluate(data_dir: str, output_dir: str, model_path: str = None) -> dict:
    import tensorflow as tf
    import pandas as pd

    os.makedirs(output_dir, exist_ok=True)

    if model_path is None:
        for candidate in [CFG["checkpoint_gen"],
                          os.path.join(output_dir, "srgan_gen_final.h5")]:
            if os.path.exists(candidate):
                model_path = candidate
                break
    if model_path is None or not os.path.exists(model_path):
        log.error("No trained SRGAN generator found. Run training first.")
        return {}

    log.info("Loading generator from %s …", model_path)
    generator = tf.keras.models.load_model(model_path, compile=False)

    lr_test, hr_test = _load_patches(data_dir, "test")
    log.info("Running SRGAN inference on %d test patches …", len(lr_test))

    preds   = generator.predict(lr_test, batch_size=8, verbose=0)
    preds   = np.clip(preds, 0.0, 1.0)

    records = [compute_metrics(preds[i], hr_test[i]) for i in range(len(preds))]
    df      = pd.DataFrame(records)
    mean    = {k: float(df[k].mean()) for k in ["rmse", "psnr", "ssim"]}
    df.to_csv(os.path.join(output_dir, "srgan_metrics_per_patch.csv"), index=False)

    with open(os.path.join(output_dir, "srgan_summary.json"), "w") as f:
        json.dump(mean, f, indent=2)

    log.info(
        "SRGAN — RMSE: %.4f | PSNR: %.2f dB | SSIM: %.4f",
        mean["rmse"], mean["psnr"], mean["ssim"],
    )
    return mean


def predict_scene(lr_scene_path: str, output_path: str) -> None:
    """Apply trained SRGAN generator to a full Landsat scene GeoTIFF."""
    import tensorflow as tf
    import rasterio
    from rasterio.transform import Affine

    model_path = CFG["checkpoint_gen"]
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"SRGAN generator checkpoint not found: {model_path}")

    generator = tf.keras.models.load_model(model_path, compile=False)

    with rasterio.open(lr_scene_path) as src:
        meta      = src.meta.copy()
        lr_data   = src.read().astype(np.float32)   # (C, H, W)
        old_t     = src.transform

    C, H, W = lr_data.shape
    scale   = PATCH["scale"]
    new_res_x = old_t.a / scale
    new_res_y = old_t.e / scale
    new_transform = Affine(new_res_x, 0.0, old_t.c,
                           0.0, new_res_y, old_t.f)

    # Pad to make divisible by scale
    pad_h = (scale - H % scale) % scale
    pad_w = (scale - W % scale) % scale
    lr_pad = np.pad(lr_data, ((0, 0), (0, pad_h), (0, pad_w)), mode="reflect")

    # Predict in tiles of (hr_size / scale) to avoid OOM
    tile_lr = PATCH["hr_size"] // scale
    lr_pad  = np.transpose(lr_pad, (1, 2, 0))   # (H, W, C)
    Hp, Wp  = lr_pad.shape[:2]
    sr_out  = np.zeros((Hp * scale, Wp * scale, C), dtype=np.float32)

    for y in range(0, Hp, tile_lr):
        for x in range(0, Wp, tile_lr):
            tile = lr_pad[y:y+tile_lr, x:x+tile_lr, :]
            if tile.shape[0] < tile_lr or tile.shape[1] < tile_lr:
                # Pad partial edge tile
                tile = np.pad(tile,
                              ((0, tile_lr - tile.shape[0]),
                               (0, tile_lr - tile.shape[1]),
                               (0, 0)), mode="reflect")
            tile_input = tile[np.newaxis, ...]
            sr_tile    = generator.predict(tile_input, verbose=0)[0]
            sr_tile    = np.clip(sr_tile, 0.0, 1.0)
            sr_out[y*scale:(y+tile_lr)*scale,
                   x*scale:(x+tile_lr)*scale, :] = sr_tile

    # Crop back to original size
    sr_out = sr_out[:H*scale, :W*scale, :]
    sr_out = np.transpose(sr_out, (2, 0, 1))   # back to (C, H, W)

    meta.update({
        "width"    : W * scale,
        "height"   : H * scale,
        "transform": new_transform,
    })
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with rasterio.open(output_path, "w", **meta) as dst:
        dst.write(sr_out)
    log.info("SRGAN SR scene saved → %s", output_path)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Train and evaluate SRGAN for super-resolution.")
    parser.add_argument("--data",       default=PROC_LANDSAT)
    parser.add_argument("--output",     default=RES_SRGAN)
    parser.add_argument("--epochs",     type=int,   default=CFG["epochs"])
    parser.add_argument("--batch",      type=int,   default=CFG["batch_size"])
    parser.add_argument("--lr",         type=float, default=CFG["lr_gen"])
    parser.add_argument("--lr_disc",    type=float, default=CFG["lr_disc"])
    parser.add_argument("--eval_only",  action="store_true")
    parser.add_argument("--model",      default=None)
    parser.add_argument("--scene",      default=None,
                        help="Predict on a full Landsat scene GeoTIFF.")
    parser.add_argument("--scene_out",  default=None)
    args = parser.parse_args()

    if args.scene:
        out = args.scene_out or args.scene.replace(".tif", "_srgan_sr.tif")
        predict_scene(args.scene, out)
    elif args.eval_only:
        evaluate(args.data, args.output, model_path=args.model)
    else:
        train(args.data, args.output, args.epochs, args.batch, args.lr, args.lr_disc)
        evaluate(args.data, args.output)


if __name__ == "__main__":
    main()
